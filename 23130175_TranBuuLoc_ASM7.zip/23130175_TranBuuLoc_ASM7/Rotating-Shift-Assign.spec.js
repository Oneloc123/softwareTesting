'use strict';

const { test, expect } = require('@playwright/test');
const crypto = require('node:crypto');

const BASE_URL = process.env.HORILLA_BASE_URL || 'https://hr.demo.horilla.com';
test.use({ baseURL: BASE_URL });

const ROUTES = {
  workSchedules: '/employee/work-schedules/',
};

/* ============================================================
 *  Universal helpers
 * ============================================================ */

async function settle(page, timeout = 6000) {
  await page.waitForFunction(
    () => !document.querySelector('.htmx-request, .htmx-swapping'),
    null, { timeout }
  ).catch(() => {});
  await page.waitForLoadState('networkidle').catch(() => {});
}

async function stableCount(locator, iterations = 15, delay = 150) {
  let prev = -1;
  for (let i = 0; i < iterations; i += 1) {
    const n = await locator.count();
    if (n === prev) return n;
    prev = n;
    await new Promise(r => setTimeout(r, delay));
  }
  return prev;
}

async function waitForModalClose(page, timeout = 15000) {
  await settle(page, 2000);
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const open = await page.evaluate(() => {
      const m = document.querySelector('#genericModal');
      return m && m.classList.contains('oh-modal--show');
    });
    if (!open) return true;
    await page.waitForTimeout(500);
  }
  await page.evaluate(() => {
    document.querySelectorAll('.oh-modal--show').forEach(el => el.classList.remove('oh-modal--show'));
    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
    document.body.classList.remove('modal-open');
  });
  return false;
}

async function ensureAuthenticated(page) {
  await page.goto('/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await settle(page, 4000);
  if (!/\/login\//i.test(new URL(page.url()).pathname)) return;

  const body = await page.locator('body').innerText();
  const usernameMatch = body.match(/(?:username|user name)\s*[:=]\s*([A-Za-z0-9_.@-]+)/i);
  const passwordMatch = body.match(/password\s*[:=]\s*([^\s]+)/i);
  if (!usernameMatch || !passwordMatch) throw new Error('Không đọc được thông tin đăng nhập.');

  await page.getByLabel(/username/i).or(page.locator('input[name="username"], input[type="email"]')).first().fill(usernameMatch[1]);
  await page.getByLabel(/password/i).or(page.locator('input[name="password"], input[type="password"]')).first().fill(passwordMatch[1]);
  await page.getByRole('button', { name: /sign in|log in|login/i }).click();
  await page.waitForURL(url => !/\/login\//i.test(url.pathname), { timeout: 45000, waitUntil: 'commit' });
  await settle(page, 4000);
}

test.beforeEach(async ({ page }) => {
  await ensureAuthenticated(page);
});

const MARKER_PREFIX = '[TC-RSA]';

function timestampSuffix() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}-${crypto.randomBytes(3).toString('hex')}`;
}

function fixtureMarker(id, detail = 'fixture') {
  return `${MARKER_PREFIX} ${id} ${detail} ${timestampSuffix()}`;
}

function registerFixture(page, fixture) {
  if (!Array.isArray(page.__tcFixtures)) page.__tcFixtures = [];
  page.__tcFixtures.push(fixture);
  return fixture;
}

function relativeDateIso(offset = 0) {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() + offset);
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function toRegex(value) {
  if (value instanceof RegExp) return value;
  return new RegExp(String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
}

async function firstVisible(locator) {
  const count = await locator.count();
  for (let i = 0; i < count; i += 1) {
    if (await locator.nth(i).isVisible()) return locator.nth(i);
  }
  return null;
}

/* ============================================================
 *  Form scope / dialog helpers
 * ============================================================ */

async function findFormScope(page) {
  const modals = page.locator('.oh-modal--show');
  const n = await modals.count();
  for (let i = n - 1; i >= 0; i -= 1) {
    if (await modals.nth(i).isVisible()) return modals.nth(i);
  }
  const dialog = await firstVisible(page.locator('[role="dialog"]:visible'));
  return dialog || page;
}

async function closeVisibleDialog(page) {
  const modals = page.locator('.oh-modal--show');
  const n = await modals.count();
  for (let i = n - 1; i >= 0; i -= 1) {
    const m = modals.nth(i);
    if (!(await m.isVisible())) continue;
    const close = await firstVisible(m.getByRole('button', { name: /close|cancel|discard|×/i }));
    if (close) await close.click().catch(() => {});
    else await page.keyboard.press('Escape');
    await m.waitFor({ state: 'hidden', timeout: 4000 }).catch(() => {});
    break;
  }
  await page.evaluate(() => {
    document.querySelectorAll('.oh-modal--show').forEach(el => el.classList.remove('oh-modal--show'));
    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
    document.body.classList.remove('modal-open');
  }).catch(() => {});
}

/* ============================================================
 *  Interaction helpers
 * ============================================================ */

async function clickByName(scope, names, options = {}) {
  const roles = options.roles || ['button', 'link', 'menuitem'];
  const allowText = options.allowText !== false;

  for (const name of names) {
    const pattern = toRegex(name);
    for (const role of roles) {
      const item = await firstVisible(scope.getByRole(role, { name: pattern }));
      if (item && await item.isEnabled()) { await item.click(); return item; }
    }
    const titled = scope.locator('[title], [aria-label]');
    const count = await titled.count();
    for (let i = 0; i < count; i += 1) {
      const item = titled.nth(i);
      const label = `${await item.getAttribute('title') || ''} ${await item.getAttribute('aria-label') || ''}`;
      if (pattern.test(label) && await item.isVisible() && await item.isEnabled()) {
        await item.click();
        return item;
      }
    }
    if (allowText) {
      const item = await firstVisible(scope.getByText(pattern, { exact: false }));
      if (item && await item.isEnabled()) { await item.click(); return item; }
    }
  }
  throw new Error(`Không tìm thấy control ${names.join('/')}.`);
}

async function findField(scope, aliases, selectors = []) {
  for (const alias of aliases) {
    const locator = scope.getByLabel(toRegex(alias));
    const field = await firstVisible(locator);
    if (field) return field;
    if (await locator.count()) return locator.first();
  }
  for (const alias of aliases) {
    const esc = String(alias).replace(/"/g, '\\"');
    const field = await firstVisible(scope.locator(
      `input[placeholder*="${esc}" i], textarea[placeholder*="${esc}" i], input[aria-label*="${esc}" i]`
    ));
    if (field) return field;
  }
  for (const selector of selectors) {
    const field = await firstVisible(scope.locator(selector));
    if (field) return field;
  }
  return null;
}

async function fillField(scope, aliases, value, selectors = []) {
  const field = await findField(scope, aliases, selectors);
  if (!field) throw new Error(`Không tìm thấy trường ${aliases.join('/')}.`);
  if (!(await field.isVisible())) throw new Error(`Trường ${aliases.join('/')} không hiển thị.`);
  await field.fill(String(value));
  return field;
}

/* ============================================================
 *  select2 helpers
 * ============================================================ */

async function widgetForHiddenSelect(scope, field) {
  const id = await field.getAttribute('id');
  if (id) {
    const safeId = id.replace(/([^a-zA-Z0-9_-])/g, '\\$1');
    const widget = await firstVisible(scope.locator(`#select2-${safeId}-container`));
    if (widget) return widget;
  }
  const sibling = await firstVisible(field.locator('xpath=following-sibling::*[1]'));
  if (sibling) return sibling;
  return firstVisible(field.locator('xpath=..').locator('[role="combobox"], .select2-selection, [aria-haspopup="listbox"]'));
}

async function selectWidgetOption(page, scope, aliases, options = {}) {
  let field = await findField(scope, aliases, options.selectors || []);
  if (!field && options.allowFirstWidget) {
    field = await firstVisible(scope.locator('select, [role="combobox"], [aria-haspopup="listbox"]'));
  }
  if (!field) throw new Error(`Không tìm thấy trường chọn ${aliases.join('/')}.`);

  const tag = await field.evaluate(el => el.tagName.toLowerCase());
  const wanted = options.text || '';
  const excluded = options.exclude || [];

  if (tag === 'select' && await field.isVisible()) {
    const choices = await field.locator('option').evaluateAll(items => items.map(item => ({
      text: (item.textContent || '').trim(), value: item.value, disabled: item.disabled,
    })));
    const selected = choices.find(item =>
      !item.disabled && item.value && item.text &&
      !/choose|select|---------|none$/i.test(item.text) &&
      !excluded.some(v => v && item.text.toLowerCase() === v.toLowerCase()) &&
      (!wanted || item.text.toLowerCase().includes(wanted.toLowerCase()))
    );
    if (!selected) throw new Error(`Không có option phù hợp cho ${aliases.join('/')}. Có: ${choices.map(c => c.text).join(' | ')}`);
    await field.selectOption(selected.value);
    return selected.text;
  }

  let widget = await widgetForHiddenSelect(scope, field);
  if (!widget && await field.isVisible()) widget = field;
  if (!widget) throw new Error(`Không tìm thấy widget cho ${aliases.join('/')}.`);

  await widget.scrollIntoViewIfNeeded();
  const opened = await firstVisible(page.getByRole('option'))
    || await firstVisible(page.locator('.select2-results__option:visible'));
  if (!opened) await widget.click();

  const search = await firstVisible(page.locator('input.select2-search__field, input[role="searchbox"]'));
  if (search && wanted) await search.fill(wanted);

  let optionsLocator = page.getByRole('option');
  if (!(await optionsLocator.count())) optionsLocator = page.locator('.select2-results__option:visible');

  const count = await optionsLocator.count();
  for (let i = 0; i < count; i += 1) {
    const item = optionsLocator.nth(i);
    if (!(await item.isVisible())) continue;
    const text = (await item.innerText()).trim();
    if (!text || /no results|loading|choose|select/i.test(text)) continue;
    if (excluded.some(v => v && text.toLowerCase() === v.toLowerCase())) continue;
    if (wanted && !text.toLowerCase().includes(wanted.toLowerCase())) continue;
    await item.click();
    return text;
  }
  throw new Error(`Dropdown ${aliases.join('/')} không có lựa chọn phù hợp.`);
}

/* ============================================================
 *  Page-specific helpers (Rotating Shift Assign)
 * ============================================================ */

async function openRotatingShiftPage(page) {
  await page.goto(ROUTES.workSchedules, { waitUntil: 'domcontentloaded' });
  await settle(page, 4000);

  const tab = await firstVisible(page.locator('.work-schedules-tab-btn[data-tab-id="rotating-shift"]'));
  if (tab) {
    const isActive = await tab.evaluate(el => el.classList.contains('oh-tabs__tab--active'));
    if (!isActive) { await tab.click(); await settle(page, 4000); }
  }

  await expect(page.getByText(/Rotating Shift Assigns/i).first()).toBeVisible({ timeout: 20000 });
  await expect(page.locator('#rotating-shift-container, table tbody tr').first()).toBeVisible({ timeout: 20000 });
  await settle(page, 2000);
  await expect(page.locator('body')).not.toContainText(/Internal Server Error|Traceback|502 Bad Gateway/i);
}

async function openCreateForm(page) {
  await closeVisibleDialog(page);
  const createBtn = page.locator('a[hx-get*="rotating-shift-assign-add"]').first();
  if (await createBtn.count()) await createBtn.click();
  else await clickByName(page, ['Create', 'Add'], { roles: ['button', 'link'] });
  await settle(page, 3000);
  const scope = await findFormScope(page);
  await expect(scope).toBeVisible({ timeout: 15000 });
  await expect(scope.locator('form').first()).toBeVisible({ timeout: 10000 });
  return scope;
}

async function submitForm(scope) {
  const form = scope.locator('form').first();
  let responsePromise = null;

  if (await form.count()) {
    const invalid = await form.evaluate(el =>
      Array.from(el.elements).some(c => c.willValidate && !c.checkValidity())
    );
    if (!invalid) {
      responsePromise = scope.page().waitForResponse(r => {
        const req = r.request();
        const headers = req.headers();
        return req.isNavigationRequest()
          || String(headers['hx-request'] || '').toLowerCase() === 'true'
          || (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method())
            && ['xhr', 'fetch'].includes(req.resourceType()));
      }, { timeout: 30000 }).catch(() => null);
    }
  }

  let clicked = false;
  if (await form.count()) {
    const btn = await firstVisible(form.locator(
      'button[type="submit"]:not([disabled]), input[type="submit"]:not([disabled]), button.oh-btn--secondary:not([disabled]), input.oh-btn--secondary:not([disabled])'
    ));
    if (btn) { await btn.click(); clicked = true; }
  }
  if (!clicked) {
    await clickByName(scope, ['Save', 'Submit', 'Create', 'Confirm'], {
      roles: ['button', 'link'], allowText: false,
    });
  }
  if (responsePromise) await responsePromise;
  await settle(scope.page(), 4000);
}

/* ============================================================
 *  Confirm handler (SweetAlert2 / htmx modal / native)
 * ============================================================ */

async function performConfirm(page, accept = true) {
  const swal = page.locator('.swal2-popup');
  const htmxModal = page.locator('#deleteConfirmation.oh-modal--show, .oh-modal--show:has(#deleteConfirmationBody)');
  const nativeHandler = async (d) => { accept ? await d.accept() : await d.dismiss(); };
  page.once('dialog', nativeHandler);

  let mode = null;
  for (let i = 0; i < 20; i += 1) {
    if (await swal.isVisible().catch(() => false)) { mode = 'swal'; break; }
    if (await htmxModal.isVisible().catch(() => false)) { mode = 'htmx'; break; }
    await page.waitForTimeout(250);
  }
  page.off('dialog', nativeHandler);

  if (mode === 'swal') {
    if (accept) await page.locator('.swal2-confirm').click().catch(() => {});
    else await page.locator('.swal2-cancel').click().catch(() => {});
    await swal.waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
  } else if (mode === 'htmx') {
    const body = page.locator('#deleteConfirmationBody');
    if (accept) {
      const btn = await firstVisible(body.getByRole('button', { name: /confirm|delete|yes|ok|remove/i }));
      if (btn) await btn.click();
      else {
        const form = body.locator('form button[type="submit"]').first();
        if (await form.isVisible().catch(() => false)) await form.click();
      }
    } else {
      const cancel = await firstVisible(body.getByRole('button', { name: /cancel|close|no/i }));
      if (cancel) await cancel.click();
      else await page.keyboard.press('Escape');
    }
    await page.locator('#deleteConfirmation').waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
  }
  await settle(page, 3000);
  return mode || 'native';
}

/* ============================================================
 *  List / rows helpers
 * ============================================================ */

async function rsaRows(page) {
  const container = page.locator('#rotating-shift-container');
  if (await container.count()) return container.locator('table tbody tr[data-instance-id]');
  return page.locator('table tbody tr[data-instance-id]');
}

async function rowsContaining(page, text) {
  const container = page.locator('#rotating-shift-container');
  if (await container.count()) {
    return container.locator('table tbody tr[data-instance-id]').filter({ hasText: text });
  }
  return page.locator('table tbody tr[data-instance-id]').filter({ hasText: text });
}

async function searchInput(page) {
  const box = await firstVisible(page.getByRole('searchbox'));
  if (box) return box;
  const byName = await firstVisible(page.locator('input[name="search"]'));
  if (byName) return byName;
  const byPlaceholder = await firstVisible(page.locator('input[placeholder*="search" i]'));
  if (byPlaceholder) return byPlaceholder;
  throw new Error('Không tìm thấy ô Search.');
}

async function doSearch(page, term) {
  const search = await searchInput(page);
  const before = await rsaRows(page).count();

  const responsePromise = page.waitForResponse(r => {
    const req = r.request();
    const headers = req.headers();
    return req.url().includes('rotating-shift-request-list')
      || String(headers['hx-request'] || '').toLowerCase() === 'true'
      || req.isNavigationRequest();
  }, { timeout: 8000 }).catch(() => null);

  await search.fill(term);
  await responsePromise;
  await settle(page, 3000);

  if (term && before > 0) {
    await page.waitForFunction(
      (b) => {
        const c = document.querySelector('#rotating-shift-container');
        const rows = c ? c.querySelectorAll('table tbody tr[data-instance-id]').length
                       : document.querySelectorAll('table tbody tr[data-instance-id]').length;
        return rows !== b;
      }, before, { timeout: 5000 }
    ).catch(() => {});
  }
  await settle(page, 2000);
}

async function clickRowAction(row, actions) {
  for (const action of actions) {
    const pattern = toRegex(action);
    const button = await firstVisible(row.getByRole('button', { name: pattern }))
      || await firstVisible(row.getByRole('link', { name: pattern }));
    if (button) { await button.click(); return button; }
    const esc = String(action).replace(/"/g, '\\"');
    const titled = await firstVisible(row.locator(`[title*="${esc}" i], [aria-label*="${esc}" i]`));
    if (titled) { await titled.click(); return titled; }
  }
  throw new Error(`Không tìm thấy action ${actions.join('/')} trên row.`);
}

/* ============================================================
 *  Form field specific helpers
 * ============================================================ */

async function pickEmployee(page, scope, desiredText = '') {
  return await selectWidgetOption(page, scope, ['Employee', 'Employees'], {
    text: desiredText, allowFirstWidget: true,
    selectors: ['select[name="employee_id"]'],
  });
}

async function pickRotatingShift(page, scope, desiredText = '') {
  return await selectWidgetOption(page, scope, ['Rotating Shift', 'Shift'], {
    text: desiredText, allowFirstWidget: true,
    selectors: ['select[name="rotating_shift_id"]'],
  });
}

async function fillBasedOn(page, scope, value = 'After') {
  const field = await findField(scope, ['Based On', 'Based on'], ['select[name="based_on"]']);
  if (!field) return null;
  return await selectWidgetOption(page, scope, ['Based On', 'Based on'], {
    text: value, extraSelectors: ['select[name="based_on"]'], allowFirstWidget: true,
  });
}

async function fillRotate(page, scope, value = 7) {
  const field = await findField(
    scope,
    ['Rotate', 'Rotate After', 'Rotate after', 'Rotating Column', 'Rotating column'],
    ['input[name="rotating_column"]', 'input[name="rotate"]', 'input[name="rotate_after"]', 'select[name="rotating_column"]']
  );
  if (!field) return null;
  const tag = await field.evaluate(el => el.tagName.toLowerCase());
  if (tag === 'select') {
    return await selectWidgetOption(page, scope, ['Rotate', 'Rotating Column'], { allowFirstWidget: true })
      .catch(() => null);
  }
  await field.fill(String(value));
  return String(value);
}

async function fillStartDate(page, scope, value) {
  const field = await findField(scope, ['Start Date', 'Start date'], ['input[name="start_date"]', 'input[type="date"]']);
  if (!field) return null;
  await field.fill(value);
  return value;
}

/* ============================================================
 *  Fixture creation / cleanup
 * ============================================================ */

async function createRsaFixture(page, id, options = {}) {
  await openRotatingShiftPage(page);
  const marker = fixtureMarker(id, 'rsa');
  const fixture = registerFixture(page, {
    type: 'rotatingShift', route: ROUTES.workSchedules, marker, searchKey: null, created: false,
  });

  const form = await openCreateForm(page);

  const employee = options.employee || await pickEmployee(page, form, options.employeeText || '');
  const rotatingShift = options.rotatingShift || await pickRotatingShift(page, form, options.shiftText || '');
  const basedOn = options.basedOn === null ? null : await fillBasedOn(page, form, options.basedOn || 'After');
  const rotate = await fillRotate(page, form, options.rotate || 7);
  const startDate = await fillStartDate(page, form, options.startDate || relativeDateIso(1));

  fixture.employee = employee;
  fixture.rotatingShift = rotatingShift;
  fixture.basedOn = basedOn;
  fixture.rotate = rotate;
  fixture.startDate = startDate;
  fixture.cleanupSearch = employee || undefined;
  fixture.matchTexts = [employee, rotatingShift].filter(Boolean);

  if (options.submit !== false) {
    await submitForm(form);
    await waitForModalClose(page);
    await settle(page, 2000);
    await openRotatingShiftPage(page);
    if (fixture.cleanupSearch) await doSearch(page, fixture.cleanupSearch);
    const row = await firstVisible(await rowsContaining(page, employee));
    if (!row) throw new Error(`Không thấy row cho ${employee} sau khi tạo.`);
    fixture.created = true;
    if (fixture.cleanupSearch) await doSearch(page, '');
  }

  return { fixture, marker, employee, rotatingShift, basedOn, rotate, startDate, form };
}

async function cleanupRowsForFixture(page, fixture) {
  let rows = await rowsContaining(page, fixture.employee || fixture.marker);
  if (await rows.count()) return rows;
  const term = fixture.cleanupSearch || fixture.employee || fixture.marker;
  const search = await firstVisible(page.getByRole('searchbox'))
    || await firstVisible(page.locator('input[name="search"], input[placeholder*="search" i]'));
  if (!search || !term) return rows;
  await search.fill(term);
  await settle(page, 3000);
  return rowsContaining(page, term);
}

async function deleteFixture(page, fixture) {
  await page.goto(fixture.route, { waitUntil: 'domcontentloaded' });
  await settle(page, 4000);
  await openRotatingShiftPage(page);

  for (let attempt = 0; attempt < 20; attempt += 1) {
    const rows = await cleanupRowsForFixture(page, fixture);
    const count = await rows.count();
    if (!count) return;
    const delBtn = await firstVisible(rows.first().locator('[title="Delete"], [title="Remove"]'));
    if (!delBtn) return;
    const confirmP = performConfirm(page, true);
    await delBtn.click();
    await confirmP;
    await settle(page, 2000);
  }
}

async function cleanupCreatedFixtures(page) {
  if (page.isClosed()) return;
  const fixtures = Array.isArray(page.__tcFixtures) ? [...page.__tcFixtures].reverse() : [];
  const errors = [];
  for (const fixture of fixtures) {
    if (!fixture.created) continue;
    try { await deleteFixture(page, fixture); }
    catch (e) {
      if (/Test ended|Target closed|has been closed/i.test(e.message)) {
        console.warn(`[cleanup skipped] ${fixture.marker}: ${e.message}`);
        continue;
      }
      errors.push(new Error(`Cleanup ${fixture.marker}: ${e.message}`, { cause: e }));
    }
  }
  page.__tcFixtures = [];
  if (errors.length) throw new AggregateError(errors, 'Cleanup thất bại một số fixture.');
}

test.afterEach(async ({ page }) => {
  if (page.isClosed()) return;
  try { await cleanupCreatedFixtures(page); }
  catch (e) {
    if (!/Test ended|Target closed|has been closed/i.test(e.message)) {
      console.warn('[afterEach]', e.message);
    }
  }
});

/* ============================================================
 *  Run case dispatcher
 * ============================================================ */

async function runRotatingShiftCase(page, id) {
  switch (id) {
    /* ---------- ACCESS ---------- */
    case 'ROTATING_SHIFT_ACCESS_01': {
      await openRotatingShiftPage(page);
      await expect(page.locator('.work-schedules-tab-btn[data-tab-id="rotating-shift"]')).toHaveClass(/oh-tabs__tab--active/);
      await expect(page.getByText(/Rotating Shift Assigns/i).first()).toBeVisible();
      await expect(page.locator('#rotating-shift-container')).toBeVisible();
      break;
    }

    case 'ROTATING_SHIFT_TAB_NAV_01': {
      await openRotatingShiftPage(page);
      const wtTab = page.locator('.work-schedules-tab-btn[data-tab-id="rotating-work-type"]');
      await wtTab.click();
      await settle(page, 4000);
      await expect(wtTab).toHaveClass(/oh-tabs__tab--active/);
      const rsTab = page.locator('.work-schedules-tab-btn[data-tab-id="rotating-shift"]');
      await rsTab.click();
      await settle(page, 4000);
      await expect(rsTab).toHaveClass(/oh-tabs__tab--active/);
      await expect(page.getByText(/Rotating Shift Assigns/i).first()).toBeVisible();
      break;
    }

    /* ---------- LIST ---------- */
    case 'ROTATING_SHIFT_LIST_LAYOUT_01': {
      await openRotatingShiftPage(page);
      const headers = page.getByRole('columnheader');
      const expected = ['Employee', 'Rotating Shift', 'Based on', 'Rotate', 'Start Date', 'Current Shift', 'Next Switch', 'Next Shift', 'Actions'];
      const headersText = (await headers.allInnerTexts()).map(t => t.replace(/\s+/g, ' ').trim());
      for (const col of expected) {
        expect(headersText.some(h => new RegExp(col, 'i').test(h)),
          `Bảng phải có cột "${col}". Có: ${headersText.join(' | ')}`).toBe(true);
      }
      await expect(page.locator('input[name="search"]')).toBeVisible();
      await expect(page.getByText(/Filter/i).first()).toBeVisible();
      await expect(page.getByText(/Actions/i).first()).toBeVisible();
      await expect(page.locator('a[hx-get*="rotating-shift-assign-add"]').first()).toBeVisible();
      break;
    }

    case 'ROTATING_SHIFT_LIST_DATA_01': {
      await openRotatingShiftPage(page);
      const rows = await rsaRows(page);
      const count = await stableCount(rows);
      expect(count, 'Bảng phải có ít nhất 1 dòng dữ liệu mẫu').toBeGreaterThan(0);
      for (let i = 0; i < Math.min(3, count); i += 1) {
        const row = rows.nth(i);
        const text = await row.innerText();
        expect(/(.+)\s\(([^)]+)\)/.test(text) || /NTI\d+/.test(text),
          `Dòng ${i}: Employee phải có format "Tên (Mã)". Nội dung: ${text.slice(0, 200)}`).toBe(true);
        expect(/After|Weekly|Weekend|Monthly/i.test(text),
          `Dòng ${i}: Based on phải là After/Weekend/Monthly`).toBe(true);
        expect(/Rotate\s+after\s+\d+\s+days?/i.test(text),
          `Dòng ${i}: cột Rotate phải có format "Rotate after N days"`).toBe(true);
        const dates = text.match(/\d{4}-\d{2}-\d{2}/g);
        expect(dates && dates.length >= 2,
          `Dòng ${i}: phải có ít nhất 2 ngày (Start Date, Next Switch)`).toBe(true);
      }
      break;
    }

    /* ---------- SEARCH ---------- */
    case 'ROTATING_SHIFT_SEARCH_EMPLOYEE_01': {
      await openRotatingShiftPage(page);
      const rows = await rsaRows(page);
      expect(await rows.count()).toBeGreaterThan(0);
      const empMatch = (await rows.first().innerText()).match(/([A-Z][a-z]+)/);
      if (!empMatch) { test.skip(true, 'Không đọc được tên employee mẫu'); break; }
      const term = empMatch[1];
      await doSearch(page, term);
      const filtered = await rsaRows(page);
      const count = await filtered.count();
      expect(count, `Search "${term}" phải có kết quả`).toBeGreaterThan(0);
      for (let i = 0; i < count; i += 1) {
        await expect(filtered.nth(i)).toContainText(new RegExp(term, 'i'));
      }
      await doSearch(page, '');
      break;
    }

    case 'ROTATING_SHIFT_SEARCH_BADGE_01': {
      await openRotatingShiftPage(page);
      const rows = await rsaRows(page);
      expect(await rows.count()).toBeGreaterThan(0);
      const badgeMatch = (await rows.first().innerText()).match(/NTI\d+/);
      if (!badgeMatch) { test.skip(true, 'Không có badge ID trong dữ liệu mẫu'); break; }
      await doSearch(page, badgeMatch[0]);
      expect(await rsaRows(page).count(), `Search badge "${badgeMatch[0]}" phải có kết quả`).toBeGreaterThan(0);
      await doSearch(page, '');
      break;
    }

    case 'ROTATING_SHIFT_SEARCH_NO_RESULT_01': {
      await openRotatingShiftPage(page);
      const baseline = await rsaRows(page).count();
      expect(baseline, 'Cần có ít nhất 1 row trước khi test no-result').toBeGreaterThan(0);
      await doSearch(page, 'xyz_does_not_exist_' + Date.now());
      expect(await rsaRows(page).count(), 'Search không tồn tại phải trả 0 kết quả').toBe(0);
      await doSearch(page, '');
      await expect.poll(async () => (await rsaRows(page).count()), { timeout: 8000 })
        .toBeGreaterThanOrEqual(baseline);
      break;
    }

    /* ---------- FILTER ---------- */
    case 'ROTATING_SHIFT_FILTER_BASED_ON_01': {
      await openRotatingShiftPage(page);
      const afterRows = await rowsContaining(page, 'After');
      if (await afterRows.count() === 0) { test.skip(true, 'Không có dữ liệu mẫu Based on=After'); break; }

      await clickByName(page, ['Filter'], { roles: ['button', 'link'] });
      const panel = await findFormScope(page);
      await expect(panel).toBeVisible();
      const basedOnField = await findField(panel, ['Based On', 'Based on'], ['select[name="based_on"]']);
      expect(basedOnField, 'Filter panel phải có Based On').not.toBeNull();
      await selectWidgetOption(page, panel, ['Based On', 'Based on'], {
        text: 'After', extraSelectors: ['select[name="based_on"]'], allowFirstWidget: true,
      });
      await clickByName(panel, ['Apply', 'Search', 'Filter'], { roles: ['button'], allowText: false });
      await settle(page, 4000);

      const filtered = await rsaRows(page);
      const count = await filtered.count();
      expect(count).toBeGreaterThan(0);
      for (let i = 0; i < count; i += 1) {
        await expect(filtered.nth(i)).toContainText(/After/i);
      }
      break;
    }

    case 'ROTATING_SHIFT_FILTER_EMPLOYEE_01': {
      await openRotatingShiftPage(page);
      const rows = await rsaRows(page);
      expect(await rows.count()).toBeGreaterThan(0);
      const empMatch = (await rows.first().innerText()).match(/([A-Z][a-z]+\s+[A-Z][a-z]+)\s\(NTI/);
      if (!empMatch) { test.skip(true, 'Không đọc được tên employee'); break; }

      await clickByName(page, ['Filter'], { roles: ['button', 'link'] });
      const panel = await findFormScope(page);
      await expect(panel).toBeVisible();
      const empField = await findField(panel, ['Employee'], ['select[name="employee_id"]']);
      if (!empField) { test.skip(true, 'Filter không có trường Employee'); break; }

      await selectWidgetOption(page, panel, ['Employee'], {
        text: empMatch[1], extraSelectors: ['select[name="employee_id"]'], allowFirstWidget: true,
      });
      await clickByName(panel, ['Apply', 'Search', 'Filter'], { roles: ['button'], allowText: false });
      await settle(page, 4000);
      expect(await rsaRows(page).count()).toBeGreaterThan(0);
      break;
    }

    case 'ROTATING_SHIFT_FILTER_ROTATING_SHIFT_01': {
      await openRotatingShiftPage(page);
      const rows = await rsaRows(page);
      expect(await rows.count()).toBeGreaterThan(0);
      const shiftMatch = (await rows.first().innerText()).match(/(Morning|Evening|Night|Regular)\s*\/?\s*(Morning|Evening|Night|Regular)?\s*Rotation/i);
      if (!shiftMatch) { test.skip(true, 'Không đọc được tên Rotating Shift'); break; }

      await clickByName(page, ['Filter'], { roles: ['button', 'link'] });
      const panel = await findFormScope(page);
      await expect(panel).toBeVisible();
      const shiftField = await findField(panel, ['Rotating Shift'], ['select[name="rotating_shift_id"]']);
      if (!shiftField) { test.skip(true, 'Filter không có Rotating Shift'); break; }

      await selectWidgetOption(page, panel, ['Rotating Shift'], {
        extraSelectors: ['select[name="rotating_shift_id"]'], allowFirstWidget: true,
      });
      await clickByName(panel, ['Apply', 'Search', 'Filter'], { roles: ['button'], allowText: false });
      await settle(page, 4000);
      expect(await rsaRows(page).count()).toBeGreaterThan(0);
      break;
    }

    case 'ROTATING_SHIFT_FILTER_COMBINED_RESET_01': {
      await openRotatingShiftPage(page);
      const baseline = await rsaRows(page).count();
      expect(baseline).toBeGreaterThan(0);

      await clickByName(page, ['Filter'], { roles: ['button', 'link'] });
      const panel = await findFormScope(page);
      await expect(panel).toBeVisible();
      await selectWidgetOption(page, panel, ['Based On', 'Based on'], {
        text: 'After', extraSelectors: ['select[name="based_on"]'], allowFirstWidget: true,
      });
      await clickByName(panel, ['Apply', 'Search', 'Filter'], { roles: ['button'], allowText: false });
      await settle(page, 4000);

      await clickByName(page, ['Filter'], { roles: ['button', 'link'] });
      const panel2 = await findFormScope(page);
      const clearBtn = await firstVisible(panel2.getByText(/Clear all/i));
      if (clearBtn) {
        await clearBtn.click();
        await settle(page, 4000);
      } else {
        await page.keyboard.press('Escape').catch(() => {});
      }
      await expect.poll(async () => (await rsaRows(page).count()), { timeout: 8000 })
        .toBeGreaterThanOrEqual(baseline);
      break;
    }

    /* ---------- CREATE FORM ---------- */
    case 'ROTATING_SHIFT_CREATE_FORM_01': {
      await openRotatingShiftPage(page);
      const form = await openCreateForm(page);
      const checks = [
        { aliases: ['Employee'], selector: 'select[name="employee_id"]' },
        { aliases: ['Rotating Shift', 'Shift'], selector: 'select[name="rotating_shift_id"]' },
        { aliases: ['Based On', 'Based on'], selector: 'select[name="based_on"]' },
      ];
      for (const item of checks) {
        const field = await findField(form, item.aliases, [item.selector]);
        expect(field, `Form Create phải có trường ${item.aliases.join('/')}`).not.toBeNull();
      }
      await closeVisibleDialog(page);
      break;
    }

    case 'ROTATING_SHIFT_CREATE_BASED_ON_OPTIONS_01': {
      await openRotatingShiftPage(page);
      const form = await openCreateForm(page);
      const field = await findField(form, ['Based On', 'Based on'], ['select[name="based_on"]']);
      expect(field, 'Phải có Based On').not.toBeNull();
      const options = await field.locator('option').evaluateAll(opts =>
        opts.map(o => (o.textContent || '').trim()).filter(Boolean)
      );
      expect(options.some(o => /^After$/i.test(o)), `Thiếu "After" (có: ${options.join(', ')})`).toBe(true);
      expect(options.some(o => /^Weekend$|^Weekly$/i.test(o)), `Thiếu "Weekend/Weekly"`).toBe(true);
      expect(options.some(o => /^Monthly$/i.test(o)), `Thiếu "Monthly"`).toBe(true);
      await closeVisibleDialog(page);
      break;
    }

    /* ---------- CREATE ---------- */
    case 'ROTATING_SHIFT_CREATE_VALID_01': {
      const { employee } = await createRsaFixture(page, id, {
        basedOn: 'After', rotate: 7, startDate: relativeDateIso(1),
      });
      await doSearch(page, employee);
      const row = await firstVisible(await rowsContaining(page, employee));
      await expect(row).toBeVisible();
      await expect(row).toContainText(employee);
      await doSearch(page, '');
      break;
    }

    case 'ROTATING_SHIFT_CREATE_MULTIPLE_01': {
      const first = await createRsaFixture(page, `${id}_A`, { basedOn: 'After' });
      const second = await createRsaFixture(page, `${id}_B`, { basedOn: 'Weekly' });
      expect(second.employee).not.toBe(first.employee);
      await expect((await rowsContaining(page, first.employee)).first()).toBeVisible();
      await expect((await rowsContaining(page, second.employee)).first()).toBeVisible();
      break;
    }

    case 'ROTATING_SHIFT_CREATE_REQUIRED_EMPLOYEE_01': {
      await openRotatingShiftPage(page);
      const form = await openCreateForm(page);
      await pickRotatingShift(page, form);
      await fillBasedOn(page, form, 'After').catch(() => {});
      await fillRotate(page, form, 7).catch(() => {});
      await fillStartDate(page, form, relativeDateIso(1)).catch(() => {});
      await submitForm(form);

      const modalOpen = await page.evaluate(() => {
        const m = document.querySelector('#genericModal');
        return m && m.classList.contains('oh-modal--show');
      });
      const hasError = await form.getByText(/required|This field|please select/i).count() > 0;
      expect(modalOpen || hasError, 'Bỏ trống Employee phải bị chặn').toBe(true);
      await closeVisibleDialog(page);
      break;
    }

    case 'ROTATING_SHIFT_CREATE_REQUIRED_SHIFT_01': {
      await openRotatingShiftPage(page);
      const form = await openCreateForm(page);
      await pickEmployee(page, form);
      await fillBasedOn(page, form, 'After').catch(() => {});
      await fillRotate(page, form, 7).catch(() => {});
      await fillStartDate(page, form, relativeDateIso(1)).catch(() => {});
      await submitForm(form);

      const modalOpen = await page.evaluate(() => {
        const m = document.querySelector('#genericModal');
        return m && m.classList.contains('oh-modal--show');
      });
      const hasError = await form.getByText(/required|This field|please select/i).count() > 0;
      expect(modalOpen || hasError, 'Bỏ trống Rotating Shift phải bị chặn').toBe(true);
      await closeVisibleDialog(page);
      break;
    }

    case 'ROTATING_SHIFT_CREATE_REQUIRED_BASED_ON_01': {
      await openRotatingShiftPage(page);
      const form = await openCreateForm(page);
      await pickEmployee(page, form);
      await pickRotatingShift(page, form);
      await fillRotate(page, form, 7).catch(() => {});
      await fillStartDate(page, form, relativeDateIso(1)).catch(() => {});
      await submitForm(form);

      const modalOpen = await page.evaluate(() => {
        const m = document.querySelector('#genericModal');
        return m && m.classList.contains('oh-modal--show');
      });
      const hasError = await form.getByText(/required|This field|please select/i).count() > 0;
      expect(modalOpen || hasError, 'Bỏ trống Based On phải bị chặn').toBe(true);
      await closeVisibleDialog(page);
      break;
    }

    case 'ROTATING_SHIFT_CREATE_PAST_DATE_01': {
      await openRotatingShiftPage(page);
      const form = await openCreateForm(page);
      await pickEmployee(page, form);
      await pickRotatingShift(page, form);
      await fillBasedOn(page, form, 'After').catch(() => {});
      await fillRotate(page, form, 7).catch(() => {});
      await fillStartDate(page, form, relativeDateIso(-5));
      await submitForm(form);

      const modalOpen = await page.evaluate(() => {
        const m = document.querySelector('#genericModal');
        return m && m.classList.contains('oh-modal--show');
      });
      test.info().annotations.push({
        type: 'note',
        description: `Past date Start Date: ${modalOpen ? 'server chấp nhận (modal đóng)' : 'modal còn mở (validation)'}`,
      });
      if (modalOpen) await closeVisibleDialog(page);
      break;
    }

    case 'ROTATING_SHIFT_DUPLICATE_EMPLOYEE_01': {
      const first = await createRsaFixture(page, `${id}_FIRST`, { basedOn: 'After' });
      await openRotatingShiftPage(page);
      const form = await openCreateForm(page);
      await pickEmployee(page, form, first.employee);
      await pickRotatingShift(page, form);
      await fillBasedOn(page, form, 'After').catch(() => {});
      await fillRotate(page, form, 7).catch(() => {});
      await fillStartDate(page, form, relativeDateIso(1)).catch(() => {});
      await submitForm(form);

      const modalOpen = await page.evaluate(() => {
        const m = document.querySelector('#genericModal');
        return m && m.classList.contains('oh-modal--show');
      });
      const hasError = await form.getByText(/already|duplicate|exist|tồn tại/i).count() > 0;
      test.info().annotations.push({
        type: 'note',
        description: `Duplicate employee: ${modalOpen || hasError ? 'bị chặn' : 'được phép tạo thêm'}`,
      });
      if (modalOpen) await closeVisibleDialog(page);
      break;
    }

    /* ---------- EDIT ---------- */
    case 'ROTATING_SHIFT_EDIT_VALID_01': {
      const { employee } = await createRsaFixture(page, id);
      await doSearch(page, employee);
      const rows = await rowsContaining(page, employee);
      expect(await rows.count()).toBeGreaterThan(0);

      await clickRowAction(rows.first(), ['Edit', 'Update']);
      await settle(page, 3000);
      const form = await findFormScope(page);
      await expect(form).toBeVisible();
      await expect(form.locator('form').first()).toBeVisible({ timeout: 10000 });

      const changed = await fillBasedOn(page, form, 'Monthly');
      if (!changed) { test.skip(true, 'Form Edit không có Based On'); break; }

      await submitForm(form);
      await waitForModalClose(page);

      await doSearch(page, employee);
      const updated = await rowsContaining(page, employee);
      await expect(updated.first()).toContainText(/Monthly/i);
      await doSearch(page, '');
      break;
    }

    case 'ROTATING_SHIFT_EDIT_CANCEL_01': {
      const { employee } = await createRsaFixture(page, id);
      await doSearch(page, employee);
      const rows = await rowsContaining(page, employee);
      expect(await rows.count()).toBeGreaterThan(0);
      const beforeText = await rows.first().innerText();

      await clickRowAction(rows.first(), ['Edit', 'Update']);
      await settle(page, 3000);
      const form = await findFormScope(page);
      await expect(form).toBeVisible();
      await fillBasedOn(page, form, 'Monthly').catch(() => {});
      await closeVisibleDialog(page);
      await settle(page, 3000);

      await doSearch(page, employee);
      const after = await rowsContaining(page, employee);
      await expect(after.first()).toHaveText(beforeText);
      await doSearch(page, '');
      break;
    }

    /* ---------- DELETE ---------- */
    case 'ROTATING_SHIFT_DELETE_CONFIRM_01': {
      const { fixture, employee } = await createRsaFixture(page, id);
      await doSearch(page, employee);
      const rows = await rowsContaining(page, employee);
      expect(await rows.count()).toBeGreaterThan(0);

      const delBtn = await firstVisible(rows.first().locator('[title="Delete"], [title="Remove"]'));
      expect(delBtn, 'Row phải có nút Delete').not.toBeNull();

      const confirmP = performConfirm(page, true);
      await delBtn.click();
      await confirmP;
      await settle(page, 3000);

      await expect.poll(async () => (await rowsContaining(page, employee)).count(),
        { timeout: 10000 }).toBe(0);

      fixture.created = false;
      await doSearch(page, '');
      break;
    }

    case 'ROTATING_SHIFT_DELETE_CANCEL_01': {
      const { employee } = await createRsaFixture(page, id);
      await doSearch(page, employee);
      const rows = await rowsContaining(page, employee);
      expect(await rows.count()).toBeGreaterThan(0);

      const delBtn = await firstVisible(rows.first().locator('[title="Delete"], [title="Remove"]'));
      if (!delBtn) { test.skip(true, 'Không có nút Delete'); break; }

      const confirmP = performConfirm(page, false);
      await delBtn.click();
      await confirmP;
      await settle(page, 3000);

      await doSearch(page, employee);
      expect(await rowsContaining(page, employee).count()).toBeGreaterThan(0);
      await doSearch(page, '');
      break;
    }

    /* ---------- ARCHIVE ---------- */
    case 'ROTATING_SHIFT_ARCHIVE_01': {
      const { fixture, employee } = await createRsaFixture(page, id);
      await doSearch(page, employee);
      const rows = await rowsContaining(page, employee);
      expect(await rows.count()).toBeGreaterThan(0);

      const archiveBtn = await firstVisible(rows.first().locator('[title="Archive"]'));
      if (!archiveBtn) { test.skip(true, 'Row không có nút Archive'); break; }

      const confirmP = performConfirm(page, true);
      await archiveBtn.click();
      await confirmP;
      await settle(page, 4000);

      await doSearch(page, employee);
      await expect.poll(async () => (await rowsContaining(page, employee)).count(),
        { timeout: 10000 }).toBe(0);

      fixture.created = false;
      await doSearch(page, '');
      break;
    }

    /* ---------- SORT ---------- */
    case 'ROTATING_SHIFT_SORT_EMPLOYEE_01': {
      await openRotatingShiftPage(page);
      const rows = await rsaRows(page);
      expect(await rows.count()).toBeGreaterThan(1);

      const employeeHeader = page.getByRole('columnheader').filter({ hasText: /Employee/i }).first();
      await expect(employeeHeader).toBeVisible();

      const readNames = async () => {
        const r = await rsaRows(page);
        const n = await r.count();
        const names = [];
        for (let i = 0; i < n; i += 1) {
          const cells = r.nth(i).locator('td');
          if (await cells.count() >= 2) names.push((await cells.nth(1).innerText()).trim());
        }
        return names;
      };

      await employeeHeader.click();
      await settle(page, 3000);
      const order1 = await readNames();

      await employeeHeader.click();
      await settle(page, 3000);
      const order2 = await readNames();

      expect(order1.length).toBeGreaterThan(0);
      expect(order2.length).toBe(order1.length);
      break;
    }

    /* ---------- PERSISTENCE ---------- */
    case 'ROTATING_SHIFT_PERSIST_RELOAD_01': {
      const { employee } = await createRsaFixture(page, id);
      await page.reload({ waitUntil: 'domcontentloaded' });
      await settle(page, 4000);
      const tab = page.locator('.work-schedules-tab-btn[data-tab-id="rotating-shift"]');
      await expect(tab).toHaveClass(/oh-tabs__tab--active/, { timeout: 15000 });

      await doSearch(page, employee);
      expect(await rowsContaining(page, employee).count()).toBeGreaterThan(0);
      await doSearch(page, '');
      break;
    }

    /* ---------- EXPORT ---------- */
    case 'ROTATING_SHIFT_EXPORT_01': {
      await openRotatingShiftPage(page);
      const actionsBtn = page.locator('button').filter({ hasText: /^\s*Actions\s*$/ }).first();
      await expect(actionsBtn).toBeVisible();
      await actionsBtn.click();
      await settle(page, 1000);

      const exportItem = await firstVisible(page.locator('.dropdown-content a').filter({ hasText: /^\s*Export\s*$/ }));
      if (!exportItem) { test.skip(true, 'Actions không có Export'); break; }
      await exportItem.click();
      await settle(page, 3000);

      const form = await findFormScope(page);
      await expect(form).toBeVisible();
      const submitBtn = form.locator('button[type="submit"], input[type="submit"]').filter({ hasText: /Export/i });
      await expect(submitBtn.first()).toBeVisible();
      await closeVisibleDialog(page);
      break;
    }

    /* ---------- SECURITY ---------- */
    case 'ROTATING_SHIFT_XSS_SEARCH_01': {
      await openRotatingShiftPage(page);
      const payload = '<img src=x onerror="window.__xssTest=true">';
      await doSearch(page, payload);
      expect(await page.evaluate(() => window.__xssTest)).toBeUndefined();
      expect(await page.locator('img[src="x"]').count()).toBe(0);
      await doSearch(page, '');
      break;
    }

    /* ---------- DATA INTEGRITY ---------- */
    case 'ROTATING_SHIFT_LIST_INTEGRITY_01': {
      await openRotatingShiftPage(page);
      const initial = await rsaRows(page);
      const initialCount = await stableCount(initial);
      expect(initialCount).toBeGreaterThan(0);

      await clickByName(page, ['Filter'], { roles: ['button', 'link'] });
      const panel = await findFormScope(page);
      const clearBtn = await firstVisible(panel.getByText(/Clear all/i));
      if (clearBtn) { await clearBtn.click(); await settle(page, 4000); }

      await expect.poll(async () => (await rsaRows(page).count()), { timeout: 8000 })
        .toBe(initialCount);
      break;
    }

    default:
      throw new Error(`Không có kịch bản Rotating Shift Assign cho ${id}`);
  }
}

/* ============================================================
 *  TESTS
 * ============================================================ */

const TESTS = [
  ['ROTATING_SHIFT_ACCESS_01', 'Truy cập trang Work Schedules và tab Rotating Shift Assign'],
  ['ROTATING_SHIFT_TAB_NAV_01', 'Chuyển đổi giữa các tab Work Schedules'],
  ['ROTATING_SHIFT_LIST_LAYOUT_01', 'Kiểm tra bố cục bảng danh sách và toolbar'],
  ['ROTATING_SHIFT_LIST_DATA_01', 'Đọc và xác thực dữ liệu mẫu trong bảng'],
  ['ROTATING_SHIFT_SEARCH_EMPLOYEE_01', 'Tìm kiếm theo tên Employee'],
  ['ROTATING_SHIFT_SEARCH_BADGE_01', 'Tìm kiếm theo Badge ID'],
  ['ROTATING_SHIFT_SEARCH_NO_RESULT_01', 'Tìm kiếm không có kết quả'],
  ['ROTATING_SHIFT_FILTER_BASED_ON_01', 'Lọc theo Based On = After'],
  ['ROTATING_SHIFT_FILTER_EMPLOYEE_01', 'Lọc theo Employee cụ thể'],
  ['ROTATING_SHIFT_FILTER_ROTATING_SHIFT_01', 'Lọc theo Rotating Shift'],
  ['ROTATING_SHIFT_FILTER_COMBINED_RESET_01', 'Kết hợp filter và Clear all'],
  ['ROTATING_SHIFT_CREATE_FORM_01', 'Kiểm tra form Create có đủ trường'],
  ['ROTATING_SHIFT_CREATE_BASED_ON_OPTIONS_01', 'Kiểm tra options của Based On'],
  ['ROTATING_SHIFT_CREATE_VALID_01', 'Tạo Rotating Shift Assign hợp lệ'],
  ['ROTATING_SHIFT_CREATE_MULTIPLE_01', 'Tạo nhiều Rotating Shift Assign'],
  ['ROTATING_SHIFT_CREATE_REQUIRED_EMPLOYEE_01', 'Bỏ trống Employee bị chặn'],
  ['ROTATING_SHIFT_CREATE_REQUIRED_SHIFT_01', 'Bỏ trống Rotating Shift bị chặn'],
  ['ROTATING_SHIFT_CREATE_REQUIRED_BASED_ON_01', 'Bỏ trống Based On bị chặn'],
  ['ROTATING_SHIFT_CREATE_PAST_DATE_01', 'Kiểm tra xử lý Start Date quá khứ'],
  ['ROTATING_SHIFT_DUPLICATE_EMPLOYEE_01', 'Tạo trùng Employee bị chặn hoặc cho phép'],
  ['ROTATING_SHIFT_EDIT_VALID_01', 'Chỉnh sửa Rotating Shift Assign'],
  ['ROTATING_SHIFT_EDIT_CANCEL_01', 'Đóng form Edit không lưu thay đổi'],
  ['ROTATING_SHIFT_DELETE_CONFIRM_01', 'Xóa Rotating Shift Assign với confirm'],
  ['ROTATING_SHIFT_DELETE_CANCEL_01', 'Hủy thao tác xóa'],
  ['ROTATING_SHIFT_ARCHIVE_01', 'Archive Rotating Shift Assign'],
  ['ROTATING_SHIFT_SORT_EMPLOYEE_01', 'Sắp xếp theo cột Employee'],
  ['ROTATING_SHIFT_PERSIST_RELOAD_01', 'Dữ liệu còn sau reload'],
  ['ROTATING_SHIFT_EXPORT_01', 'Export danh sách qua modal'],
  ['ROTATING_SHIFT_XSS_SEARCH_01', 'Search với payload XSS không thực thi'],
  ['ROTATING_SHIFT_LIST_INTEGRITY_01', 'Dữ liệu bảng nhất quán sau thao tác filter'],
];

for (const [id, title] of TESTS) {
  test(`${id} - ${title}`, async ({ page }) => {
    await runRotatingShiftCase(page, id);
  });
}