'use strict';

const { test, expect } = require('@playwright/test');
const crypto = require('node:crypto');

const BASE_URL = process.env.HORILLA_BASE_URL || 'https://hr.demo.horilla.com';
test.use({ baseURL: BASE_URL });

const ROUTES = {
  requests: '/employee/requests/',
};

/* ============================================================
 *  Universal helpers
 * ============================================================ */

async function settle(page, timeout = 6000) {
  await page.waitForFunction(
    () => !document.querySelector('.htmx-request, .htmx-swapping'),
    null, { timeout }
  ).catch(() => {});
  await page.waitForLoadState('networkidle').catch(() => {});
}

async function stableCount(locator, iterations = 15, delay = 150) {
  let prev = -1;
  for (let i = 0; i < iterations; i += 1) {
    const n = await locator.count();
    if (n === prev) return n;
    prev = n;
    await new Promise(r => setTimeout(r, delay));
  }
  return prev;
}

async function waitForModalClose(page, timeout = 15000) {
  await settle(page, 2000);
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const open = await page.evaluate(() => {
      const m = document.querySelector('#genericModal');
      return m && m.classList.contains('oh-modal--show');
    });
    if (!open) return true;
    await page.waitForTimeout(500);
  }
  await page.evaluate(() => {
    document.querySelectorAll('.oh-modal--show').forEach(el => el.classList.remove('oh-modal--show'));
    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
    document.body.classList.remove('modal-open');
  });
  return false;
}

async function ensureAuthenticated(page) {
  await page.goto('/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await settle(page, 4000);
  if (!/\/login\//i.test(new URL(page.url()).pathname)) return;

  const body = await page.locator('body').innerText();
  const usernameMatch = body.match(/(?:username|user name)\s*[:=]\s*([A-Za-z0-9_.@-]+)/i);
  const passwordMatch = body.match(/password\s*[:=]\s*([^\s]+)/i);
  if (!usernameMatch || !passwordMatch) throw new Error('Không đọc được thông tin đăng nhập.');

  await page.getByLabel(/username/i).or(page.locator('input[name="username"], input[type="email"]')).first().fill(usernameMatch[1]);
  await page.getByLabel(/password/i).or(page.locator('input[name="password"], input[type="password"]')).first().fill(passwordMatch[1]);
  await page.getByRole('button', { name: /sign in|log in|login/i }).click();
  await page.waitForURL(url => !/\/login\//i.test(url.pathname), { timeout: 45000, waitUntil: 'commit' });
  await settle(page, 4000);
}

test.beforeEach(async ({ page }) => {
  await ensureAuthenticated(page);
});

const MARKER_PREFIX = '[TC-SR]';

function timestampSuffix() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}-${crypto.randomBytes(3).toString('hex')}`;
}

function fixtureMarker(id, label = 'fixture') {
  return `${MARKER_PREFIX} ${id} ${label} ${timestampSuffix()}`;
}

function registerFixture(page, fixture) {
  if (!Array.isArray(page.__tcFixtures)) page.__tcFixtures = [];
  page.__tcFixtures.push(fixture);
  return fixture;
}

function relativeDateIso(daysFromToday = 0) {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() + daysFromToday);
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function toRegex(value) {
  if (value instanceof RegExp) return value;
  return new RegExp(String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
}

async function firstVisible(locator) {
  const count = await locator.count();
  for (let i = 0; i < count; i += 1) {
    if (await locator.nth(i).isVisible()) return locator.nth(i);
  }
  return null;
}

/* ============================================================
 *  Form scope / dialog helpers
 * ============================================================ */

async function findFormScope(page) {
  const modals = page.locator('.oh-modal--show');
  const n = await modals.count();
  for (let i = n - 1; i >= 0; i -= 1) {
    if (await modals.nth(i).isVisible()) return modals.nth(i);
  }
  const dialog = await firstVisible(page.locator('[role="dialog"]:visible'));
  return dialog || page;
}

async function closeVisibleDialog(page) {
  const modals = page.locator('.oh-modal--show');
  const n = await modals.count();
  for (let i = n - 1; i >= 0; i -= 1) {
    const m = modals.nth(i);
    if (!(await m.isVisible())) continue;
    const close = await firstVisible(m.getByRole('button', { name: /close|cancel|discard|×/i }));
    if (close) await close.click().catch(() => {});
    else await page.keyboard.press('Escape');
    await m.waitFor({ state: 'hidden', timeout: 4000 }).catch(() => {});
    break;
  }
  await page.evaluate(() => {
    document.querySelectorAll('.oh-modal--show').forEach(el => el.classList.remove('oh-modal--show'));
    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
    document.body.classList.remove('modal-open');
  }).catch(() => {});
}

/* ============================================================
 *  Interaction helpers
 * ============================================================ */

async function clickByName(scope, names, options = {}) {
  const roles = options.roles || ['button', 'link', 'menuitem'];
  const allowText = options.allowText !== false;

  for (const name of names) {
    const pattern = toRegex(name);
    for (const role of roles) {
      const item = await firstVisible(scope.getByRole(role, { name: pattern }));
      if (item && await item.isEnabled()) { await item.click(); return item; }
    }
    const titled = scope.locator('[title], [aria-label]');
    const count = await titled.count();
    for (let i = 0; i < count; i += 1) {
      const item = titled.nth(i);
      const label = `${await item.getAttribute('title') || ''} ${await item.getAttribute('aria-label') || ''}`;
      if (pattern.test(label) && await item.isVisible() && await item.isEnabled()) {
        await item.click();
        return item;
      }
    }
    if (allowText) {
      const item = await firstVisible(scope.getByText(pattern, { exact: false }));
      if (item && await item.isEnabled()) { await item.click(); return item; }
    }
  }
  throw new Error(`Không tìm thấy control ${names.join('/')}.`);
}

async function findField(scope, aliases, selectors = []) {
  for (const alias of aliases) {
    const locator = scope.getByLabel(toRegex(alias));
    const field = await firstVisible(locator);
    if (field) return field;
    if (await locator.count()) return locator.first();
  }
  for (const alias of aliases) {
    const esc = String(alias).replace(/"/g, '\\"');
    const field = await firstVisible(scope.locator(
      `input[placeholder*="${esc}" i], textarea[placeholder*="${esc}" i], input[aria-label*="${esc}" i]`
    ));
    if (field) return field;
  }
  for (const selector of selectors) {
    const field = await firstVisible(scope.locator(selector));
    if (field) return field;
  }
  return null;
}

async function fillField(scope, aliases, value, selectors = []) {
  const field = await findField(scope, aliases, selectors);
  if (!field) throw new Error(`Không tìm thấy trường ${aliases.join('/')}.`);
  if (!(await field.isVisible())) throw new Error(`Trường ${aliases.join('/')} không hiển thị.`);
  await field.fill(String(value));
  return field;
}

/* ============================================================
 *  select2 helpers
 * ============================================================ */

async function widgetForHiddenSelect(scope, field) {
  const id = await field.getAttribute('id');
  if (id) {
    const safeId = id.replace(/([^a-zA-Z0-9_-])/g, '\\$1');
    const widget = await firstVisible(scope.locator(`#select2-${safeId}-container`));
    if (widget) return widget;
  }
  const sibling = await firstVisible(field.locator('xpath=following-sibling::*[1]'));
  if (sibling) return sibling;
  return firstVisible(field.locator('xpath=..').locator('[role="combobox"], .select2-selection, [aria-haspopup="listbox"]'));
}

async function selectWidgetOption(page, scope, aliases, options = {}) {
  let field = await findField(scope, aliases, options.selectors || []);
  if (!field && options.allowFirstWidget) {
    field = await firstVisible(scope.locator('select, [role="combobox"], [aria-haspopup="listbox"]'));
  }
  if (!field) throw new Error(`Không tìm thấy trường chọn ${aliases.join('/')}.`);

  const tag = await field.evaluate(el => el.tagName.toLowerCase());
  const wanted = options.text || '';
  const excluded = options.exclude || [];

  if (tag === 'select' && await field.isVisible()) {
    const choices = await field.locator('option').evaluateAll(items => items.map(item => ({
      text: (item.textContent || '').trim(), value: item.value, disabled: item.disabled,
    })));
    const selected = choices.find(item =>
      !item.disabled && item.value && item.text &&
      !/choose|select|---------|none$/i.test(item.text) &&
      !excluded.some(v => v && item.text.toLowerCase() === v.toLowerCase()) &&
      (!wanted || item.text.toLowerCase().includes(wanted.toLowerCase()))
    );
    if (!selected) throw new Error(`Không có option phù hợp cho ${aliases.join('/')}. Có: ${choices.map(c => c.text).join(' | ')}`);
    const isMultiple = await field.getAttribute('multiple') !== null;
    if (isMultiple) {
      const sel = await field.locator('option:checked').evaluateAll(i => i.map(x => x.value).filter(Boolean));
      if (!sel.includes(selected.value)) await field.selectOption([...sel, selected.value]);
    } else await field.selectOption(selected.value);
    return selected.text;
  }

  let widget = await widgetForHiddenSelect(scope, field);
  if (!widget && await field.isVisible()) widget = field;
  if (!widget) throw new Error(`Không tìm thấy widget cho ${aliases.join('/')}.`);

  await widget.scrollIntoViewIfNeeded();
  const opened = await firstVisible(page.getByRole('option'))
    || await firstVisible(page.locator('.select2-results__option:visible'));
  if (!opened) await widget.click();

  const search = await firstVisible(page.locator('input.select2-search__field, input[role="searchbox"]'));
  if (search && wanted) await search.fill(wanted);

  let optionsLocator = page.getByRole('option');
  if (!(await optionsLocator.count())) optionsLocator = page.locator('.select2-results__option:visible');

  const count = await optionsLocator.count();
  for (let i = 0; i < count; i += 1) {
    const item = optionsLocator.nth(i);
    if (!(await item.isVisible())) continue;
    const text = (await item.innerText()).trim();
    if (!text || /no results|loading|choose|select/i.test(text)) continue;
    if (excluded.some(v => v && text.toLowerCase() === v.toLowerCase())) continue;
    if (wanted && !text.toLowerCase().includes(wanted.toLowerCase())) continue;
    await item.click();
    return text;
  }
  throw new Error(`Dropdown ${aliases.join('/')} không có lựa chọn phù hợp.`);
}

async function clickToggle(scope, aliases) {
  for (const alias of aliases) {
    const field = await firstVisible(scope.getByLabel(toRegex(alias)));
    if (field) {
      const type = await field.getAttribute('type');
      if (type === 'checkbox' || type === 'radio') {
        if (!(await field.isChecked())) await field.check();
      } else await field.click();
      return field;
    }
    const label = await firstVisible(scope.getByText(toRegex(alias), { exact: false }));
    if (label) { await label.click(); return label; }
  }
  throw new Error(`Không tìm thấy toggle ${aliases.join('/')}.`);
}

/* ============================================================
 *  Page-specific helpers (Shift Request – tab-based)
 * ============================================================ */

async function openRequestsTab(page, tabLabel) {
  await page.goto(ROUTES.requests, { waitUntil: 'domcontentloaded' });
  await settle(page, 4000);
  const tab = await firstVisible(page.locator('.requests-tab-btn').filter({ hasText: toRegex(tabLabel) }));
  if (tab) {
    const isActive = await tab.evaluate(el => el.classList.contains('oh-tabs__tab--active'));
    if (!isActive) {
      await tab.click();
      await settle(page, 4000);
    }
  }
  await expect(page.locator('body')).not.toContainText(/Internal Server Error|Traceback|502 Bad Gateway/i);
}

async function openShiftRequests(page) {
  await openRequestsTab(page, /^Shift Requests$/);
  await expect(page.getByText(/Shift Requests/i).first()).toBeVisible({ timeout: 20000 });
  await expect(page.locator('#shift-container, table tbody tr').first()).toBeVisible({ timeout: 20000 });
  await settle(page, 2000);
}

async function openShiftAllocations(page) {
  await openRequestsTab(page, /Shift Allocations/i);
  await expect(page.getByText(/Shift Allocations/i).first()).toBeVisible({ timeout: 20000 });
  await settle(page, 2000);
}

async function openCreateForm(page) {
  await closeVisibleDialog(page);
  const createLink = page.locator('a[hx-get="/shift-request/"], a[hx-get*="shift-request"]').first();
  if (await createLink.count()) await createLink.click();
  else await clickByName(page, ['Create', 'Add'], { roles: ['button', 'link'] });
  await settle(page, 3000);
  const form = await findFormScope(page);
  await expect(form).toBeVisible();
  await expect(form.locator('form').first()).toBeVisible({ timeout: 10000 });
  return form;
}

async function submitForm(scope) {
  const form = scope.locator('form').first();
  let responsePromise = null;

  if (await form.count()) {
    const invalid = await form.evaluate(el =>
      Array.from(el.elements).some(c => c.willValidate && !c.checkValidity())
    );
    if (!invalid) {
      responsePromise = scope.page().waitForResponse(r => {
        const req = r.request();
        const headers = req.headers();
        return req.isNavigationRequest()
          || String(headers['hx-request'] || '').toLowerCase() === 'true'
          || (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method())
            && ['xhr', 'fetch'].includes(req.resourceType()));
      }, { timeout: 30000 }).catch(() => null);
    }
  }

  let clicked = false;
  if (await form.count()) {
    const btn = await firstVisible(form.locator(
      'button[type="submit"]:not([disabled]), input[type="submit"]:not([disabled]), button.oh-btn--secondary:not([disabled]), input.oh-btn--secondary:not([disabled])'
    ));
    if (btn) { await btn.click(); clicked = true; }
  }
  if (!clicked) {
    await clickByName(scope, ['Save', 'Submit', 'Create', 'Confirm'], {
      roles: ['button', 'link'], allowText: false,
    });
  }
  if (responsePromise) await responsePromise;
  await settle(scope.page(), 4000);
}

/* ============================================================
 *  Confirm handler (SweetAlert2 / htmx modal / native)
 * ============================================================ */

async function performConfirm(page, accept = true) {
  const swal = page.locator('.swal2-popup');
  const htmxModal = page.locator('#deleteConfirmation.oh-modal--show, .oh-modal--show:has(#deleteConfirmationBody)');
  const nativeHandler = async (d) => { accept ? await d.accept() : await d.dismiss(); };
  page.once('dialog', nativeHandler);

  let mode = null;
  for (let i = 0; i < 20; i += 1) {
    if (await swal.isVisible().catch(() => false)) { mode = 'swal'; break; }
    if (await htmxModal.isVisible().catch(() => false)) { mode = 'htmx'; break; }
    await page.waitForTimeout(250);
  }
  page.off('dialog', nativeHandler);

  if (mode === 'swal') {
    if (accept) await page.locator('.swal2-confirm').click().catch(() => {});
    else await page.locator('.swal2-cancel').click().catch(() => {});
    await swal.waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
  } else if (mode === 'htmx') {
    const body = page.locator('#deleteConfirmationBody');
    if (accept) {
      const btn = await firstVisible(body.getByRole('button', { name: /confirm|delete|yes|ok|remove/i }));
      if (btn) await btn.click();
      else {
        const form = body.locator('form button[type="submit"]').first();
        if (await form.isVisible().catch(() => false)) await form.click();
      }
    } else {
      const cancel = await firstVisible(body.getByRole('button', { name: /cancel|close|no/i }));
      if (cancel) await cancel.click();
      else await page.keyboard.press('Escape');
    }
    await page.locator('#deleteConfirmation').waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
  }
  await settle(page, 3000);
  return mode || 'native';
}

/* ============================================================
 *  Rows / search helpers
 * ============================================================ */

async function shiftRows(page) {
  const container = page.locator('#shift-container');
  if (await container.count()) return container.locator('table tbody tr[data-instance-id]');
  return page.locator('table tbody tr[data-instance-id]');
}

async function rowsContaining(page, text) {
  const container = page.locator('#shift-container');
  if (await container.count()) {
    return container.locator('table tbody tr[data-instance-id]').filter({ hasText: text });
  }
  return page.locator('table tbody tr[data-instance-id]').filter({ hasText: text });
}

async function searchInput(page) {
  const box = await firstVisible(page.getByRole('searchbox'));
  if (box) return box;
  const byName = await firstVisible(page.locator('input[name="search"]'));
  if (byName) return byName;
  const byPlaceholder = await firstVisible(page.locator('input[placeholder*="search" i]'));
  if (byPlaceholder) return byPlaceholder;
  throw new Error('Không tìm thấy ô Search.');
}

async function doSearch(page, term) {
  const search = await searchInput(page);
  const before = await shiftRows(page).count();

  const responsePromise = page.waitForResponse(r => {
    const req = r.request();
    const headers = req.headers();
    return req.url().includes('list-shift-request')
      || String(headers['hx-request'] || '').toLowerCase() === 'true'
      || req.isNavigationRequest();
  }, { timeout: 8000 }).catch(() => null);

  await search.fill(term);
  await responsePromise;
  await settle(page, 3000);

  if (term && before > 0) {
    await page.waitForFunction(
      (b) => {
        const c = document.querySelector('#shift-container');
        const rows = c ? c.querySelectorAll('table tbody tr[data-instance-id]').length
                       : document.querySelectorAll('table tbody tr[data-instance-id]').length;
        return rows !== b;
      }, before, { timeout: 5000 }
    ).catch(() => {});
  }
  await settle(page, 2000);
}

async function clickRowAction(row, actions) {
  for (const action of actions) {
    const pattern = toRegex(action);
    const button = await firstVisible(row.getByRole('button', { name: pattern }))
      || await firstVisible(row.getByRole('link', { name: pattern }));
    if (button) { await button.click(); return button; }
    const esc = String(action).replace(/"/g, '\\"');
    const titled = await firstVisible(row.locator(`[title*="${esc}" i], [aria-label*="${esc}" i]`));
    if (titled) { await titled.click(); return titled; }
  }
  throw new Error(`Không tìm thấy action ${actions.join('/')} trên row.`);
}

async function findRequestRow(page, fixture) {
  await doSearch(page, fixture.employee || '');
  const rows = await shiftRows(page);
  const count = await rows.count();
  if (!count) throw new Error(`Không thấy row nào sau khi search "${fixture.employee}"`);

  // Filter by date text in row
  if (fixture.requestedDate) {
    const matched = rows.filter({ hasText: fixture.requestedDate });
    if (await matched.count()) return matched.first();
  }
  return rows.first();
}

async function selectRequestQuickFilter(page, label) {
  const btn = page.locator('.oh-row-status-indication').filter({ hasText: toRegex(label) }).first();
  if (await btn.count()) {
    await btn.click();
    await settle(page, 3000);
    return;
  }
  await clickByName(page, ['Filter'], { roles: ['button', 'link'] });
  const panel = await findFormScope(page);
  await selectWidgetOption(page, panel, ['Status'], { text: label, allowFirstWidget: true });
  await clickByName(panel, ['Apply', 'Search', 'Filter'], { roles: ['button'], allowText: false });
  await settle(page, 3000);
}

/* ============================================================
 *  Fixture creation / cleanup
 * ============================================================ */

async function createShiftRequestFixture(page, id, options = {}) {
  const marker = fixtureMarker(id, 'shift-request');

  await openShiftRequests(page);

  const fixture = registerFixture(page, {
    type: 'shiftRequest',
    route: ROUTES.requests,
    marker,
    searchKey: null,
    created: false,
  });

  const form = await openCreateForm(page);
  const employee = options.employee || await selectWidgetOption(page, form, ['Employee', 'Employees'], {
    allowFirstWidget: true, selectors: ['select[name="employee_id"]'],
  });
  const shift = options.shift || await selectWidgetOption(page, form, ['Requesting Shift', 'Shift'], {
    allowFirstWidget: true, selectors: ['select[name="shift_id"]'],
  });

  const requestedDate = options.date || relativeDateIso(2);
  await fillField(form, ['Requested Date', 'Start Date'], requestedDate, ['input[name="requested_date"]', 'input[type="date"]']);

  let requestedTill = null;
  if (options.permanent) {
    await clickToggle(form, ['Permanent Request']);
  } else {
    requestedTill = options.till || relativeDateIso(5);
    await fillField(
      form,
      ['Requested Till', 'Requested Till Date', 'End Date'],
      requestedTill,
      ['input[name="requested_till"]', 'input[type="date"]']
    );
  }

  if (options.description !== null) {
    await fillField(form, ['Description'], options.description || marker,
      ['textarea[name="description"]', 'input[name="description"]']);
  }

  fixture.employee = employee;
  fixture.shift = shift;
  fixture.requestedDate = requestedDate;
  fixture.requestedTill = requestedTill;
  fixture.cleanupSearch = employee;
  fixture.matchTexts = [employee, requestedDate].filter(Boolean);

  if (options.submit !== false) {
    await submitForm(form);
    await waitForModalClose(page);
    await settle(page, 2000);
    await openShiftRequests(page);
    await doSearch(page, employee);
    const visible = await shiftRows(page);
    if (!(await visible.count())) throw new Error(`Không thấy row nào cho ${employee}.`);
    fixture.created = true;
    await doSearch(page, '');
  }

  return { fixture, marker, employee, shift, requestedDate, requestedTill, form };
}

async function cleanupRowsForFixture(page, fixture) {
  const term = fixture.cleanupSearch || fixture.employee || fixture.marker;
  if (term) await doSearch(page, term);
  let rows = await shiftRows(page);
  if (!(await rows.count())) return rows;

  // Narrow by date if available
  if (fixture.requestedDate) {
    const narrowed = rows.filter({ hasText: fixture.requestedDate });
    if (await narrowed.count()) return narrowed;
  }
  return rows;
}

async function deleteFixture(page, fixture) {
  await page.goto(fixture.route, { waitUntil: 'domcontentloaded' });
  await settle(page, 4000);
  await openShiftRequests(page);

  for (let attempt = 0; attempt < 20; attempt += 1) {
    const rows = await cleanupRowsForFixture(page, fixture);
    const count = await rows.count();
    if (!count) return;

    const delBtn = await firstVisible(rows.first().locator('[title="Delete"], [title="Remove"]'));
    if (!delBtn) return;

    const confirmP = performConfirm(page, true);
    await delBtn.click();
    await confirmP;
    await settle(page, 2000);
  }
}

async function cleanupCreatedFixtures(page) {
  if (page.isClosed()) return;
  const fixtures = Array.isArray(page.__tcFixtures) ? [...page.__tcFixtures].reverse() : [];
  const errors = [];
  for (const fixture of fixtures) {
    if (!fixture.created) continue;
    try { await deleteFixture(page, fixture); }
    catch (e) {
      if (/Test ended|Target closed|has been closed/i.test(e.message)) {
        console.warn(`[cleanup skipped] ${fixture.marker}: ${e.message}`);
        continue;
      }
      errors.push(new Error(`Cleanup ${fixture.marker}: ${e.message}`, { cause: e }));
    }
  }
  page.__tcFixtures = [];
  if (errors.length) throw new AggregateError(errors, 'Cleanup thất bại một số fixture.');
}

test.afterEach(async ({ page }) => {
  if (page.isClosed()) return;
  try { await cleanupCreatedFixtures(page); }
  catch (e) {
    if (!/Test ended|Target closed|has been closed/i.test(e.message)) {
      console.warn('[afterEach]', e.message);
    }
  }
});

/* ============================================================
 *  Run case dispatcher
 * ============================================================ */

async function runShiftRequestCase(page, id) {
  switch (id) {
    /* ---------- ACCESS ---------- */
    case 'SHIFT_REQUEST_ACCESS_01': {
      await openShiftRequests(page);
      await expect(page.locator('.requests-tab-btn').filter({ hasText: /Shift Requests/i }).first())
        .toHaveClass(/oh-tabs__tab--active/);
      await expect(page.locator('#shift-container')).toBeVisible();
      await expect(page.locator('body')).not.toContainText(/Internal Server Error|Traceback/i);
      break;
    }

    case 'SHIFT_REQUEST_TABS_01': {
      await openShiftRequests(page);
      await expect(page.locator('.requests-tab-btn').filter({ hasText: /Shift Requests/i }).first())
        .toHaveClass(/oh-tabs__tab--active/);
      await openShiftAllocations(page);
      await expect(page.locator('.requests-tab-btn').filter({ hasText: /Shift Allocations/i }).first())
        .toHaveClass(/oh-tabs__tab--active/);

      // Có ít nhất 4 tab
      const tabs = page.locator('.requests-tab-btn');
      expect(await tabs.count()).toBeGreaterThanOrEqual(4);

      await openShiftRequests(page);
      break;
    }

    /* ---------- LIST ---------- */
    case 'SHIFT_REQUEST_LIST_LAYOUT_01': {
      await openShiftRequests(page);
      await expect(page.locator('body')).toContainText(/Shift Requests?/i);

      const headers = page.getByRole('columnheader');
      const expected = ['Employee', 'Requested Shift', 'Requested Date', 'Status', 'Actions'];
      const headersText = (await headers.allInnerTexts()).map(t => t.replace(/\s+/g, ' ').trim());
      for (const col of expected) {
        expect(headersText.some(h => new RegExp(col, 'i').test(h)),
          `Bảng phải có cột "${col}". Có: ${headersText.join(' | ')}`).toBe(true);
      }

      await expect(page.locator('input[name="search"]')).toBeVisible();
      await expect(page.getByText(/Filter/i).first()).toBeVisible();
      await expect(page.getByText(/Actions/i).first()).toBeVisible();
      await expect(page.locator('a[hx-get="/shift-request/"], a[hx-get*="shift-request"]').first()).toBeVisible();

      // 3 quick filter buttons
      const quickFilters = page.locator('.oh-row-status-indication');
      expect(await quickFilters.count()).toBeGreaterThanOrEqual(3);
      break;
    }

    case 'SHIFT_REQUEST_LIST_DATA_01': {
      await openShiftRequests(page);
      const rows = await shiftRows(page);
      const count = await stableCount(rows);
      expect(count, 'Bảng phải có ít nhất 1 dòng dữ liệu mẫu').toBeGreaterThan(0);

      for (let i = 0; i < Math.min(3, count); i += 1) {
        const row = rows.nth(i);
        const text = await row.innerText();
        // Status phải là 1 trong 3 giá trị
        expect(/Approved|Requested|Canceled|Cancelled|Rejected/i.test(text),
          `Dòng ${i}: Status phải là Approved/Requested/Canceled. Nội dung: ${text.slice(0, 200)}`).toBe(true);
        // Requested Date có format YYYY-MM-DD
        expect(/\d{4}-\d{2}-\d{2}/.test(text),
          `Dòng ${i}: phải có Requested Date`).toBe(true);
        // Employee có avatar/tên
        expect(text.length).toBeGreaterThan(10);
      }
      break;
    }

    /* ---------- SEARCH ---------- */
    case 'SHIFT_REQUEST_SEARCH_EMPLOYEE_01': {
      await openShiftRequests(page);
      const rows = await shiftRows(page);
      expect(await rows.count()).toBeGreaterThan(0);

      const empMatch = (await rows.first().innerText()).match(/([A-Z][a-z]+\s+[A-Z][a-z]+)/);
      if (!empMatch) { test.skip(true, 'Không đọc được tên employee mẫu'); break; }

      const term = empMatch[1];
      await doSearch(page, term);
      const filtered = await shiftRows(page);
      expect(await filtered.count(), `Search "${term}" phải có kết quả`).toBeGreaterThan(0);

      const count = await filtered.count();
      for (let i = 0; i < count; i += 1) {
        await expect(filtered.nth(i)).toContainText(new RegExp(term, 'i'));
      }

      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_SEARCH_NO_RESULT_01': {
      await openShiftRequests(page);
      const baseline = await shiftRows(page).count();
      expect(baseline, 'Cần có ít nhất 1 row trước khi test no-result').toBeGreaterThan(0);

      await doSearch(page, 'xyz_not_exist_' + Date.now());
      expect(await shiftRows(page).count(), 'Search không tồn tại phải trả 0 kết quả').toBe(0);

      await doSearch(page, '');
      await expect.poll(async () => (await shiftRows(page).count()), { timeout: 8000 })
        .toBeGreaterThanOrEqual(baseline);
      break;
    }

    /* ---------- FILTER ---------- */
    case 'SHIFT_REQUEST_FILTER_APPROVED_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await openShiftRequests(page);

      // Approve fixture row
      const row = await findRequestRow(page, fixture);
      const approveBtn = await firstVisible(row.locator('[title="Approve"]:not(.oh-btn--disabled)'));
      if (approveBtn) {
        const confirmP = performConfirm(page, true);
        await approveBtn.click();
        await confirmP;
      }
      await settle(page, 3000);

      await openShiftRequests(page);
      await selectRequestQuickFilter(page, 'Approved');
      await settle(page, 3000);

      await doSearch(page, fixture.employee);
      const approved = await shiftRows(page);
      if (await approved.count()) {
        await expect(approved.first()).toContainText(/Approved/i);
      }
      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_FILTER_REJECTED_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await openShiftRequests(page);

      const row = await findRequestRow(page, fixture);
      const rejectBtn = await firstVisible(row.locator('[title="Reject"]:not(.oh-btn--disabled)'));
      if (rejectBtn) {
        const confirmP = performConfirm(page, true);
        await rejectBtn.click();
        await confirmP;
      }
      await settle(page, 3000);

      await openShiftRequests(page);
      await selectRequestQuickFilter(page, 'Canceled');
      await settle(page, 3000);

      await doSearch(page, fixture.employee);
      const rejected = await shiftRows(page);
      if (await rejected.count()) {
        await expect(rejected.first()).toContainText(/Canceled|Cancelled|Rejected/i);
      }
      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_FILTER_DATE_01': {
      const { fixture } = await createShiftRequestFixture(page, id, {
        date: relativeDateIso(17),
        till: relativeDateIso(20),
      });

      await openShiftRequests(page);
      await clickByName(page, ['Filter'], { roles: ['button', 'link'] });
      const panel = await findFormScope(page);
      await expect(panel).toBeVisible();

      const fromField = await findField(
        panel, ['Requested Date From', 'Requested Date', 'Date From'],
        ['input[name="requested_date__gte"]', 'input[name="requested_date"]']
      );
      const toField = await findField(
        panel, ['Requested Date Till', 'Date Till'],
        ['input[name="requested_date__lte"]']
      );
      if (!fromField) { test.skip(true, 'Filter không có Requested Date From'); break; }

      await fromField.fill(fixture.requestedDate);
      if (toField) await toField.fill(fixture.requestedDate);

      await clickByName(panel, ['Apply', 'Search', 'Filter'], { roles: ['button'], allowText: false });
      await settle(page, 4000);

      await doSearch(page, fixture.employee);
      const rows = await shiftRows(page);
      if (await rows.count()) {
        await expect(rows.first()).toContainText(fixture.requestedDate);
      }
      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_FILTER_GROUP_BY_01': {
      await openShiftRequests(page);
      await clickByName(page, ['Filter'], { roles: ['button', 'link'] });
      const panel = await findFormScope(page);
      await expect(panel.getByText(/Filter/i).first()).toBeVisible();
      await expect(panel.getByText(/Group By/i).first()).toBeVisible();
      await page.keyboard.press('Escape').catch(() => {});
      break;
    }

    /* ---------- CREATE ---------- */
    case 'SHIFT_REQUEST_ADD_VALID_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      const row = await findRequestRow(page, fixture);
      await expect(row).toBeVisible();
      await expect(row).toContainText(fixture.requestedDate);
      await expect(row).toContainText(/Requested/i);
      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_DATE_RANGE_01': {
      const date = relativeDateIso(3);
      const till = relativeDateIso(8);
      const { fixture } = await createShiftRequestFixture(page, id, { date, till });

      const row = await findRequestRow(page, fixture);
      await expect(row).toContainText(date);
      await expect(row).toContainText(till);

      // Verify form fields exist
      const form = await openCreateForm(page);
      await expect(await findField(form, ['Requested Date', 'Start Date'], ['input[type="date"]'])).toBeVisible();
      await expect(await findField(form, ['Requested Till', 'End Date'], ['input[type="date"]'])).toBeVisible();
      await closeVisibleDialog(page);
      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_PERMANENT_TOGGLE_01': {
      await openShiftRequests(page);
      const form = await openCreateForm(page);

      const tillField = await findField(
        form, ['Requested Till', 'Requested Till Date', 'End Date'],
        ['input[name="requested_till"]', 'input[type="date"]']
      );
      expect(tillField, 'Form phải có Requested Till trước khi bật Permanent').not.toBeNull();
      await expect(tillField).toBeVisible();

      await clickToggle(form, ['Permanent Request']);
      await expect(tillField).not.toBeVisible();

      await closeVisibleDialog(page);
      break;
    }

    case 'SHIFT_REQUEST_ADD_PERMANENT_01': {
      const { fixture } = await createShiftRequestFixture(page, id, { permanent: true });
      const row = await findRequestRow(page, fixture);
      await expect(row).toBeVisible();
      await expect(row).toContainText(fixture.requestedDate);
      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_CREATE_REQUIRED_EMPLOYEE_01': {
      await openShiftRequests(page);
      const form = await openCreateForm(page);

      // Chỉ chọn shift, bỏ trống Employee
      await selectWidgetOption(page, form, ['Requesting Shift', 'Shift'], {
        allowFirstWidget: true, selectors: ['select[name="shift_id"]'],
      });
      await fillField(form, ['Requested Date', 'Start Date'], relativeDateIso(2),
        ['input[name="requested_date"]', 'input[type="date"]']);
      await fillField(form, ['Requested Till', 'End Date'], relativeDateIso(5),
        ['input[name="requested_till"]', 'input[type="date"]']);

      await submitForm(form);

      const modalOpen = await page.evaluate(() => {
        const m = document.querySelector('#genericModal');
        return m && m.classList.contains('oh-modal--show');
      });
      const hasError = await form.getByText(/required|This field|please select/i).count() > 0;
      expect(modalOpen || hasError, 'Bỏ trống Employee phải bị chặn').toBe(true);
      await closeVisibleDialog(page);
      break;
    }

    /* ---------- EDIT ---------- */
    case 'SHIFT_REQUEST_MODIFY_PENDING_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await doSearch(page, fixture.employee);
      const rows = await shiftRows(page);
      if (!(await rows.count())) { test.skip(true, 'Không có row để edit'); break; }

      const row = rows.first();
      const editBtn = await firstVisible(row.locator('[title="Edit"]:not(.oh-btn--disabled), [title="Update"]:not(.oh-btn--disabled)'));
      if (!editBtn) { test.skip(true, 'Row không có nút Edit'); break; }

      await editBtn.click();
      await settle(page, 3000);
      const form = await findFormScope(page);
      await expect(form).toBeVisible();

      // Đổi Description
      const newDesc = `${fixture.marker} modified`;
      const descField = await findField(form, ['Description'],
        ['textarea[name="description"]', 'input[name="description"]']);
      if (descField) await descField.fill(newDesc);

      await submitForm(form);
      await waitForModalClose(page);
      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_DUPLICATE_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await doSearch(page, fixture.employee);
      const rows = await shiftRows(page);
      if (!(await rows.count())) { test.skip(true, 'Không có row để duplicate'); break; }

      const dupBtn = await firstVisible(rows.first().locator('[title="Duplicate"]'));
      if (!dupBtn) { test.skip(true, 'Row không có nút Duplicate'); break; }

      await dupBtn.click();
      await settle(page, 3000);
      const form = await findFormScope(page);
      await expect(form).toBeVisible();

      // Verify form có dữ liệu copy (Employee giữ nguyên)
      await expect(form).toContainText(fixture.employee.split(' ')[0]);

      // Đổi description để tránh nhầm lẫn
      const descField = await findField(form, ['Description'],
        ['textarea[name="description"]', 'input[name="description"]']);
      if (descField) await descField.fill(`${fixture.marker} duplicate`);
      await closeVisibleDialog(page);
      await doSearch(page, '');
      break;
    }

    /* ---------- DELETE ---------- */
    case 'SHIFT_REQUEST_DELETE_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await doSearch(page, fixture.employee);
      const rows = await shiftRows(page);
      if (!(await rows.count())) { test.skip(true, 'Không có row để delete'); break; }

      const delBtn = await firstVisible(rows.first().locator('[title="Delete"], [title="Remove"]'));
      if (!delBtn) { test.skip(true, 'Row không có nút Delete'); break; }

      const confirmP = performConfirm(page, true);
      await delBtn.click();
      await confirmP;
      await settle(page, 3000);

      await doSearch(page, fixture.employee);
      const after = await shiftRows(page);
      // Có thể còn row khác cùng employee → chỉ verify count giảm
      expect(await after.count(), 'Row đã xóa phải biến mất').toBeLessThan(1);

      fixture.created = false;
      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_DELETE_CANCEL_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await doSearch(page, fixture.employee);
      const rows = await shiftRows(page);
      if (!(await rows.count())) { test.skip(true, 'Không có row để test cancel'); break; }

      const delBtn = await firstVisible(rows.first().locator('[title="Delete"], [title="Remove"]'));
      if (!delBtn) { test.skip(true, 'Row không có nút Delete'); break; }

      const confirmP = performConfirm(page, false);
      await delBtn.click();
      await confirmP;
      await settle(page, 3000);

      await doSearch(page, fixture.employee);
      expect(await shiftRows(page).count(), 'Row phải còn sau khi cancel').toBeGreaterThan(0);
      await doSearch(page, '');
      break;
    }

    /* ---------- APPROVE / REJECT ---------- */
    case 'SHIFT_REQUEST_APPROVE_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await doSearch(page, fixture.employee);
      const rows = await shiftRows(page);
      if (!(await rows.count())) { test.skip(true, 'Không có row để approve'); break; }

      const approveBtn = await firstVisible(rows.first().locator('[title="Approve"]:not(.oh-btn--disabled)'));
      if (!approveBtn) { test.skip(true, 'Row không có nút Approve enabled'); break; }

      const confirmP = performConfirm(page, true);
      await approveBtn.click();
      await confirmP;
      await settle(page, 3000);

      await doSearch(page, fixture.employee);
      await expect(shiftRows(page).first()).toContainText(/Approved/i);
      await doSearch(page, '');
      break;
    }

    case 'SHIFT_REQUEST_CANCEL_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await doSearch(page, fixture.employee);
      const rows = await shiftRows(page);
      if (!(await rows.count())) { test.skip(true, 'Không có row để reject'); break; }

      const rejectBtn = await firstVisible(rows.first().locator('[title="Reject"]:not(.oh-btn--disabled)'));
      if (!rejectBtn) { test.skip(true, 'Row không có nút Reject enabled'); break; }

      const confirmP = performConfirm(page, true);
      await rejectBtn.click();
      await confirmP;
      await settle(page, 3000);

      await doSearch(page, fixture.employee);
      const after = await shiftRows(page);
      if (await after.count()) {
        await expect(after.first()).toContainText(/Canceled|Cancelled|Rejected/i);
      }
      await doSearch(page, '');
      break;
    }

    /* ---------- SORT ---------- */
    case 'SHIFT_REQUEST_SORT_COLUMN_01': {
      await openShiftRequests(page);
      const rows = await shiftRows(page);
      expect(await rows.count()).toBeGreaterThan(1);

      const header = await firstVisible(
        page.getByRole('columnheader', { name: /Requested Date|Request Date/i })
      );
      if (!header) { test.skip(true, 'Không có cột Requested Date để sort'); break; }

      const readDates = async () => {
        const r = await shiftRows(page);
        const n = await r.count();
        const dates = [];
        for (let i = 0; i < n; i += 1) {
          const text = await r.nth(i).innerText();
          const m = text.match(/\d{4}-\d{2}-\d{2}/);
          if (m) dates.push(m[0]);
        }
        return dates;
      };

      await header.click();
      await settle(page, 3000);
      const order1 = await readDates();

      await header.click();
      await settle(page, 3000);
      const order2 = await readDates();

      expect(order1.length).toBeGreaterThan(0);
      expect(order2.length).toBe(order1.length);
      break;
    }

    /* ---------- COMMENT ---------- */
    case 'SHIFT_REQUEST_COMMENT_ADD_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await doSearch(page, fixture.employee);
      const rows = await shiftRows(page);
      if (!(await rows.count())) { test.skip(true, 'Không có row để comment'); break; }

      const commentBtn = await firstVisible(rows.first().locator('[title="Comment"], [title="Comments"]'));
      if (!commentBtn) { test.skip(true, 'Row không có nút Comment'); break; }

      await commentBtn.click();
      await settle(page, 3000);

      const panel = await findFormScope(page);
      const commentText = `${fixture.marker} comment`;
      const commentField = await findField(panel, ['Comment', 'Write a comment', 'Add comment'],
        ['textarea', 'input[name*="comment" i]']);
      if (!commentField) { test.skip(true, 'Không có trường Comment'); break; }

      await commentField.fill(commentText);
      await clickByName(panel, ['Post', 'Send', 'Save', 'Add Comment', 'Submit'],
        { roles: ['button'], allowText: false });
      await settle(page, 3000);
      await expect(page.getByText(commentText, { exact: false }).first()).toBeVisible();
      await doSearch(page, '');
      break;
    }

    /* ---------- COLUMN CHOOSER ---------- */
    case 'SHIFT_REQUEST_COLUMN_CHOOSER_01': {
      await openShiftRequests(page);
      const chooser = await firstVisible(page.locator('button[title="Customize columns"]'));
      if (!chooser) { test.skip(true, 'Không có nút Customize columns'); break; }

      await chooser.click();
      await settle(page, 1000);
      const panel = page.locator('.oh-column-config').first();
      await expect(panel).toBeVisible();

      const checkbox = panel.getByLabel(/Description/i).first();
      if (await checkbox.count()) {
        const checked = await checkbox.isChecked();
        if (checked) await checkbox.uncheck(); else await checkbox.check();
        await settle(page, 2000);
        // Restore
        if (checked) await checkbox.check(); else await checkbox.uncheck();
        await settle(page, 1000);
      }
      break;
    }

    /* ---------- ALLOCATED ---------- */
    case 'SHIFT_REQUEST_ALLOCATED_LIST_01': {
      await openShiftAllocations(page);
      await expect(page.getByText(/Shift Allocations/i).first()).toBeVisible();
      await expect(page.locator('body')).not.toContainText(/Internal Server Error|Traceback/i);
      break;
    }

    case 'SHIFT_REQUEST_USER_AVAILABILITY_01': {
      await openShiftAllocations(page);
      const col = await firstVisible(
        page.getByRole('columnheader', { name: /User Availability|Availability/i })
      );
      if (!col) { test.skip(true, 'Allocated tab không có cột User Availability'); break; }
      await expect(col).toBeVisible();
      break;
    }

    /* ---------- EXPORT ---------- */
    case 'SHIFT_REQUEST_EXPORT_01': {
      await openShiftRequests(page);
      const actionsBtn = page.locator('button').filter({ hasText: /^\s*Actions\s*$/ }).first();
      await expect(actionsBtn).toBeVisible();
      await actionsBtn.click();
      await settle(page, 1000);

      const exportItem = await firstVisible(page.locator('.dropdown-content a').filter({ hasText: /^\s*Export\s*$/ }));
      if (!exportItem) { test.skip(true, 'Actions không có Export'); break; }
      await exportItem.click();
      await settle(page, 3000);

      const form = await findFormScope(page);
      await expect(form).toBeVisible();
      const submitBtn = form.locator('button[type="submit"], input[type="submit"]').filter({ hasText: /Export/i });
      await expect(submitBtn.first()).toBeVisible();
      await closeVisibleDialog(page);
      break;
    }

    /* ---------- BULK ACTIONS ---------- */
    case 'SHIFT_REQUEST_BULK_ACTIONS_01': {
      const approved = await createShiftRequestFixture(page, `${id}_APPROVE`);
      const rejected = await createShiftRequestFixture(page, `${id}_REJECT`);

      // Bulk Approve
      await openShiftRequests(page);
      await doSearch(page, approved.fixture.employee);
      let row = (await shiftRows(page)).first();
      let cb = await firstVisible(row.locator('input.list-table-row'));
      if (cb) await cb.check();
      await settle(page, 1000);

      const actionsBtn1 = page.locator('button').filter({ hasText: /^\s*Actions\s*$/ }).first();
      if (await actionsBtn1.count()) {
        await actionsBtn1.click();
        await settle(page, 1000);
        const menuItem = await firstVisible(
          page.locator('.dropdown-content a').filter({ hasText: /Approve Requests/i })
        );
        if (menuItem) {
          const p = performConfirm(page, true);
          await menuItem.click();
          await p;
          await settle(page, 3000);
        }
      }

      // Bulk Reject
      await openShiftRequests(page);
      await doSearch(page, rejected.fixture.employee);
      row = (await shiftRows(page)).first();
      cb = await firstVisible(row.locator('input.list-table-row'));
      if (cb) await cb.check();
      await settle(page, 1000);

      const actionsBtn2 = page.locator('button').filter({ hasText: /^\s*Actions\s*$/ }).first();
      if (await actionsBtn2.count()) {
        await actionsBtn2.click();
        await settle(page, 1000);
        const menuItem = await firstVisible(
          page.locator('.dropdown-content a').filter({ hasText: /Reject Requests/i })
        );
        if (menuItem) {
          const p = performConfirm(page, true);
          await menuItem.click();
          await p;
          await settle(page, 3000);
        }
      }
      await doSearch(page, '');
      break;
    }

    /* ---------- XSS ---------- */
    case 'SHIFT_REQUEST_XSS_SEARCH_01': {
      await openShiftRequests(page);
      const payload = '<img src=x onerror="window.__xssTest=true">';
      await doSearch(page, payload);
      expect(await page.evaluate(() => window.__xssTest)).toBeUndefined();
      expect(await page.locator('img[src="x"]').count()).toBe(0);
      await doSearch(page, '');
      break;
    }

    /* ---------- PERSISTENCE ---------- */
    case 'SHIFT_REQUEST_PERSIST_RELOAD_01': {
      const { fixture } = await createShiftRequestFixture(page, id);
      await page.reload({ waitUntil: 'domcontentloaded' });
      await settle(page, 4000);
      await openShiftRequests(page);
      await doSearch(page, fixture.employee);
      expect(await shiftRows(page).count(), 'Request phải còn sau reload').toBeGreaterThan(0);
      await doSearch(page, '');
      break;
    }

    default:
      throw new Error(`Không có kịch bản Shift Request cho ${id}`);
  }
}

/* ============================================================
 *  TESTS
 * ============================================================ */

const TESTS = [
  ['SHIFT_REQUEST_ACCESS_01', 'Truy cập trang Requests và tab Shift Requests'],
  ['SHIFT_REQUEST_TABS_01', 'Chuyển đổi giữa các tab Requests'],
  ['SHIFT_REQUEST_LIST_LAYOUT_01', 'Kiểm tra bố cục bảng và toolbar'],
  ['SHIFT_REQUEST_LIST_DATA_01', 'Đọc và xác thực dữ liệu mẫu trong bảng'],
  ['SHIFT_REQUEST_SEARCH_EMPLOYEE_01', 'Tìm kiếm theo tên Employee'],
  ['SHIFT_REQUEST_SEARCH_NO_RESULT_01', 'Tìm kiếm không có kết quả'],
  ['SHIFT_REQUEST_FILTER_APPROVED_01', 'Quick filter Approved'],
  ['SHIFT_REQUEST_FILTER_REJECTED_01', 'Quick filter Canceled/Rejected'],
  ['SHIFT_REQUEST_FILTER_DATE_01', 'Lọc theo Requested Date range'],
  ['SHIFT_REQUEST_FILTER_GROUP_BY_01', 'Filter và Group By có sẵn'],
  ['SHIFT_REQUEST_ADD_VALID_01', 'Tạo Shift Request hợp lệ'],
  ['SHIFT_REQUEST_DATE_RANGE_01', 'Kiểm tra Requested Date + Requested Till'],
  ['SHIFT_REQUEST_PERMANENT_TOGGLE_01', 'Permanent Request ẩn Requested Till'],
  ['SHIFT_REQUEST_ADD_PERMANENT_01', 'Tạo permanent Shift Request'],
  ['SHIFT_REQUEST_CREATE_REQUIRED_EMPLOYEE_01', 'Bỏ trống Employee bị chặn'],
  ['SHIFT_REQUEST_MODIFY_PENDING_01', 'Chỉnh sửa Shift Request đang pending'],
  ['SHIFT_REQUEST_DUPLICATE_01', 'Duplicate Shift Request'],
  ['SHIFT_REQUEST_DELETE_01', 'Xóa Shift Request với confirm'],
  ['SHIFT_REQUEST_DELETE_CANCEL_01', 'Hủy thao tác xóa'],
  ['SHIFT_REQUEST_APPROVE_01', 'Phê duyệt Shift Request'],
  ['SHIFT_REQUEST_CANCEL_01', 'Reject/Cancel Shift Request'],
  ['SHIFT_REQUEST_SORT_COLUMN_01', 'Sắp xếp theo cột Requested Date'],
  ['SHIFT_REQUEST_COMMENT_ADD_01', 'Thêm comment cho Shift Request'],
  ['SHIFT_REQUEST_COLUMN_CHOOSER_01', 'Bật/tắt cột qua Customize columns'],
  ['SHIFT_REQUEST_ALLOCATED_LIST_01', 'Tab Shift Allocations'],
  ['SHIFT_REQUEST_USER_AVAILABILITY_01', 'Cột User Availability trong Shift Allocations'],
  ['SHIFT_REQUEST_EXPORT_01', 'Export danh sách qua modal'],
  ['SHIFT_REQUEST_BULK_ACTIONS_01', 'Bulk Approve/Reject qua Actions dropdown'],
  ['SHIFT_REQUEST_XSS_SEARCH_01', 'Search với payload XSS không thực thi'],
  ['SHIFT_REQUEST_PERSIST_RELOAD_01', 'Dữ liệu còn sau reload'],
];

for (const [id, title] of TESTS) {
  test(`${id} - ${title}`, async ({ page }) => {
    await runShiftRequestCase(page, id);
  });
}