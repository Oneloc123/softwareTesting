# Kết quả cá nhân

| Chức năng | Tổng | Passed | Failed |
|---|---:|---:|---:|
| Recruitment Candidates | 35 | 33 | 2 |
| Assets | 35 | 32 | 3 |
| Performance Meetings | 35 | 35 | 0 |
| Tổng | 105 | 100 | 5 |

Đây là attempt gần nhất của từng case qua 5 lượt đã hoàn tất ngày 31/10–01/11/2026, không phải một lần chạy toàn bộ suite. Không có thời gian thực thi chung của một đợt chạy duy nhất trong bản tổng hợp.

- CAN-V2-20: kết quả Hired khác About; cần xác minh dữ liệu/lọc.
- CAN-V2-21: thất bại ở tiền điều kiện Canceled không lưu, chưa kiểm chứng bộ lọc.
- AST-V2-25/26: không nhận được xác nhận Delete; cần kiểm tra HTMX target.
- AST-V2-30: thiếu ảnh vẫn tạo allocation; cần xác minh validation/quy tắc nghiệp vụ.

Xem index.html để tra cứu 105 ảnh và 105 log. screenshot-index.json ghi rõ ảnh chụp gốc hay khung hình video, RUN_ID, thời điểm và SHA256. Các JSON trong source-runs được giữ nguyên từ lần chạy gốc; đường dẫn attachment trong đó phản ánh máy thực thi, không có nghĩa video/trace được đóng gói ở đây.
